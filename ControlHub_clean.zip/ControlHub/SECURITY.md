# Control Hub — Security & Privacy notes (honest version)

## Kya protect hota hai
- **Auth:** har endpoint (sirf /health chhodke) token maangta hai. Master token encrypted storage mein; compare constant-time.
- **Scoped tokens:** naam wale tokens sirf READ / WRITE / HIGH_RISK ke chuninda scopes ke saath. Plain token sirf banate waqt ek baar dikhta hai (phone par sirf SHA-256 hash). Turant revoke. Banana/list/revoke sirf **master token se aur sirf local** — relay (remote agent) ke allowlist mein `/auth/*` hai hi nahi.
- **Global scope switches** (Settings) token ke upar bhi lagte hain.
- **HIGH_RISK** actions: `confirm:true` + **idempotency key** (header `X-Idempotency-Key` ya body `idempotencyKey`, 8-100 chars). Same key + same request dobara aaye to dobara execute NAHI hota, pehla jawab (`Idempotent-Replay: true`) milta hai. Same key + alag request = 422. 10 minute TTL. Relay se aane wali har request ko uska unique id khud key ban jaata hai.
- **Optional `X-Timestamp`** (epoch ms): 5 minute se purana/aage ka ho to reject.
- **Rate limit:** 300 req/min general, 20/min HIGH_RISK, file traffic ka alag bucket (1200/min), per client IP. **Emergency stop kabhi rate-limit nahi hota.**
- **Brute-force lockout:** 8 galat token / 60 sec par IP 5 minute ke liye lock.
- **Emergency Stop:** local ya remote (`POST /emergency/stop`, READ scope se bhi). Flag ab **disk par** save hota hai — restart/reboot ke baad bhi ON rehta hai. **Resume sirf phone par.**
- **Backup:** `allowBackup=false` (token/data cloud backup mein nahi jaata).
- **Files:** size limit, blocked types, SHA-256, path-traversal safe, atomic save. Scoped token sirf apni shuru ki hui transfer chhoo sakta hai (master sab).
- **Battery:** <=10% aur charging nahi to foreground UI automation ruk jaati hai.

## Privacy rules (message content)
- Audit log mein **kabhi message/typed text nahi** — sirf action type, selector kind, text ki **length**, result.
- Notifications sirf **memory** mein; DB/audit mein nahi. Title/text API se tabhi dikhta hai jab user Settings mein "Expose notification text" ON kare (default OFF).
- Task ka instruction text (jisme message ho sakta hai) DB mein rehta hai (task chalane/resume ke liye zaroori) — task delete karne ka alag option abhi nahi hai.
- Audit log sirf latest 5000 rows rakhta hai.

## Network (Step 8)
- **Default: local API aur event server sirf loopback (127.0.0.1) par sunte hain** — LAN par kuch khula nahi. Relay isi loopback se baat karta hai, isliye remote control chalta rehta hai. Serve() mein bhi non-loopback client reject hota hai (defense in depth).
- Settings mein "Allow LAN access" ON karoge to saare interfaces par sunega (PC se curl/test ke liye) — plain HTTP hai, sirf trusted WiFi par.

## Agent loop (Step 8) — screen ka text Anthropic API ko jaata hai
- `agent_start` har step par screen ke elements (text, content-desc, ids) **Anthropic API** ko bhejta hai, **backend ki ANTHROPIC_API_KEY** se; bill key ke malik ko. Isliye agent sirf explicit `agent_start(confirm=true)` par chalta hai, aur bina key ke band rehta hai.
- Screen ka text **untrusted** hai (prompt-injection ho sakti hai). Bachav **backend mein** hai, model par bharosa nahi: `allowed_packages` ke bahar koi action reject; send/pay/delete/submit-type buttons aur Enter par run **needs_approval** par ruk jata hai (`agent_approve`), timeout par kuch nahi bhejta; strict action schema; max_steps (≤40) + 5 min limit; Emergency Stop / locked phone / battery ≤10% par turant band.
- Typed text agent ke status/log mein kabhi nahi — sirf length. `auto_approve=true` approval gate hata deta hai — khatarnaak, sirf jaan-boojh kar.
- Agent ka "done" model ka apna daava hai (jo screen par dikha) — zaroori results khud verify karo.

## Live view (Step 8)
- Video nahi, **screenshot burst** (MCP `live_view`, 1-6 frames) aur optional browser page `/live/<MCP_SECRET>` (**default band**, `LIVE_VIEW=1` se ON). Screenshots mein private cheezein ho sakti hain; URL mein secret hai (browser history mein rahega).

## Task data (Step 8)
- Khatam tasks **7 din baad auto-delete** (Settings mein band kar sakte ho). `delete_task`/`purge_tasks`; `redact_when_done=true` se task khatam hote hi message text turant mit jata hai (phir retry nahi ho sakta).
- Task khatam hone par phone **pichli app/home par wapas** (`restore_app`, default ON) — Emergency Stop ya locked screen par kabhi nahi.

## Jo guarantee NAHI hai (jaanbujh kar saaf likha)
- **LAN access ON karne par plain HTTP.** Token + lockout + rate-limit bachav deta hain, par encryption nahi.
- **Replay protection poori nahi:** cleartext LAN par koi token capture kare to wo naya request bana sakta hai. Idempotency sirf *same request ki duhrayi* roakti hai.
- **"100% invisible" control nahi.** Sirf notification inline-reply screen par kuch nahi dikhata; baaki UI automation ke liye app screen par aati hai (Mode B, explicit `allowForeground`).
- **Reply ka delivery confirm nahi hota** (sirf weak evidence).
- **Alternate-selector retry** double-click kar sakta hai agar pehla click chal gaya tha par verify galat fail hua — critical buttons par `=> gone:/appears:` condition do.
- **Rollback nahi hai.** Jo action ho gaya wo wapas nahi hota.
- WhatsApp adapter ke UI selectors **starter** hain — real phone par verify nahi hue.
