import com.controlhub.app.security.*;
import java.util.*;

public class SecurityTest {
    static int pass=0, fail=0;
    static void check(boolean ok, String name){ if(ok){pass++;System.out.println("PASS  "+name);} else {fail++;System.out.println("FAIL  "+name);} }
    static class T implements RateLimiter.Clock { long t=1000; public long now(){return t;} }
    static class Mem implements ScopedTokenRegistry.Store { String d=""; public String load(){return d;} public void save(String s){d=s;} }

    public static void main(String[] a) {
        // ---- RateLimiter ----
        T clock = new T(); RateLimiter rl = new RateLimiter(clock);
        boolean all=true; for(int i=0;i<5;i++) all &= rl.tryAcquire("k",5,60000);
        check(all && !rl.tryAcquire("k",5,60000), "5 allowed, 6th blocked within window");
        check(rl.tryAcquire("other",5,60000), "separate keys independent");
        clock.t += 60001;
        check(rl.tryAcquire("k",5,60000), "window slides — allowed again after 60s");
        for(int i=0;i<7;i++) rl.recordFailure("1.2.3.4");
        check(rl.lockedForMs("1.2.3.4")==0, "7 failures -> not locked yet");
        rl.recordFailure("1.2.3.4");
        check(rl.lockedForMs("1.2.3.4")>0, "8th failure -> locked");
        check(rl.lockedForMs("9.9.9.9")==0, "other IP unaffected");
        clock.t += RateLimiter.LOCKOUT_MS + 1;
        check(rl.lockedForMs("1.2.3.4")==0, "lock expires after 5 min");
        for(int i=0;i<7;i++) rl.recordFailure("5.5.5.5");
        rl.recordSuccess("5.5.5.5"); rl.recordFailure("5.5.5.5");
        check(rl.lockedForMs("5.5.5.5")==0, "success resets failure count");
        for(int i=0;i<4;i++) rl.recordFailure("6.6.6.6");
        clock.t += RateLimiter.FAILURE_WINDOW_MS + 1;
        for(int i=0;i<4;i++) rl.recordFailure("6.6.6.6");
        check(rl.lockedForMs("6.6.6.6")==0, "failures spread across windows don't lock");

        // ---- IdempotencyStore ----
        T c2 = new T(); IdempotencyStore st = new IdempotencyStore(c2);
        String fp = IdempotencyStore.fingerprint("POST","/task/create","{\"a\":1}");
        check(st.begin("k1", fp).kind==IdempotencyStore.Kind.NEW, "first use -> NEW");
        check(st.begin("k1", fp).kind==IdempotencyStore.Kind.IN_PROGRESS, "second while running -> IN_PROGRESS");
        st.complete("k1", 200, "{\"ok\":true}");
        IdempotencyStore.Decision d = st.begin("k1", fp);
        check(d.kind==IdempotencyStore.Kind.REPLAY && d.status==200 && d.body.equals("{\"ok\":true}"), "after completion -> REPLAY with cached response");
        check(st.begin("k1", IdempotencyStore.fingerprint("POST","/task/create","{\"a\":2}")).kind==IdempotencyStore.Kind.CONFLICT, "same key, different body -> CONFLICT");
        check(st.begin("k1", IdempotencyStore.fingerprint("POST","/notification/reply","{\"a\":1}")).kind==IdempotencyStore.Kind.CONFLICT, "same key, different path -> CONFLICT");
        st.begin("k2", fp); st.complete("k2", 500, "boom");
        check(st.begin("k2", fp).kind==IdempotencyStore.Kind.NEW, "failed (5xx) request not cached — retry allowed");
        st.begin("k3", fp); st.complete("k3", 409, "{}");
        check(st.begin("k3", fp).kind==IdempotencyStore.Kind.NEW, "4xx not cached either");
        c2.t += IdempotencyStore.TTL_MS + 1;
        check(st.begin("k1", fp).kind==IdempotencyStore.Kind.NEW, "entry expires after TTL");
        for(int i=0;i<600;i++){ st.begin("bulk"+i, fp); st.complete("bulk"+i,200,"x"); }
        check(st.begin("bulk599", fp).kind==IdempotencyStore.Kind.REPLAY && st.begin("bulk0", fp).kind==IdempotencyStore.Kind.NEW, "bounded size: newest kept, oldest evicted");
        check(IdempotencyStore.isValidKey("abcdefgh") && IdempotencyStore.isValidKey("relay-1234:ab_c.d") && !IdempotencyStore.isValidKey("short") && !IdempotencyStore.isValidKey("has space here") && !IdempotencyStore.isValidKey(null), "key format validation");

        // ---- ScopedTokenRegistry ----
        Mem mem = new Mem(); ScopedTokenRegistry reg = new ScopedTokenRegistry(mem);
        ScopedTokenRegistry.Created cr = reg.create("dashboard", ScopedTokenRegistry.READ);
        check(cr.plainToken.startsWith("ch_") && cr.plainToken.length()>20, "token has ch_ prefix");
        check(!mem.d.contains(cr.plainToken), "plain token NEVER persisted (only hash)");
        ScopedTokenRegistry.Entry e = reg.authenticate(cr.plainToken);
        check(e!=null && e.mask==ScopedTokenRegistry.READ && e.name.equals("dashboard"), "authenticates with right scope mask");
        check(reg.authenticate(cr.plainToken+"x")==null && reg.authenticate("ch_nope")==null && reg.authenticate(null)==null && reg.authenticate("master-uuid")==null, "wrong/unknown tokens rejected");
        ScopedTokenRegistry reg2 = new ScopedTokenRegistry(mem); // "restart"
        check(reg2.authenticate(cr.plainToken)!=null, "survives restart (loaded from store)");
        check(reg.revoke(e.id) && reg.authenticate(cr.plainToken)==null, "revoke works immediately");
        check(!reg.revoke(e.id), "double revoke returns false");
        check(new ScopedTokenRegistry(mem).authenticate(cr.plainToken)==null, "revocation persisted");
        boolean bad=false; try { reg.create("x", 0); } catch (IllegalArgumentException ex){ bad=true; }
        check(bad, "empty scope mask rejected");
        bad=false; try { reg.create("  ", 1); } catch (IllegalArgumentException ex){ bad=true; }
        check(bad, "empty name rejected");
        ScopedTokenRegistry.Created weird = reg.create("evil\tname\nwith breaks", 3);
        check(new ScopedTokenRegistry(mem).list().size()==2 && new ScopedTokenRegistry(mem).authenticate(weird.plainToken)!=null, "tabs/newlines in name can't corrupt storage");
        Mem m3 = new Mem(); ScopedTokenRegistry r3 = new ScopedTokenRegistry(m3);
        for(int i=0;i<20;i++) r3.create("t"+i, 1);
        bad=false; try { r3.create("one too many", 1); } catch (IllegalStateException ex){ bad=true; }
        check(bad, "max 20 active tokens");
        System.out.println("\n"+pass+" passed, "+fail+" failed");
        System.exit(fail==0?0:1);
    }
}
