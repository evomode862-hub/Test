import com.controlhub.app.filetransfer.*;
import org.json.*;
import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

public class TransferTest {
    static int pass=0, fail=0;
    static void check(boolean ok, String name){ if(ok){pass++;System.out.println("PASS  "+name);} else {fail++;System.out.println("FAIL  "+name);} }
    static String sha(byte[] b) throws Exception { return TransferManager.sha256Hex(b); }
    static byte[] data(int n){ byte[] d=new byte[n]; new Random(42).nextBytes(d); return d; }
    static void sendAll(TransferManager tm, String id, byte[] d, int cs, int[] order) throws Exception {
        for(int i: order){ int off=i*cs; int len=Math.min(cs,d.length-off); tm.writeChunk(id,i,Arrays.copyOfRange(d,off,off+len)); }
    }
    public static void main(String[] a) throws Exception {
        Path dir = Files.createTempDirectory("th");
        int cs = 1024;
        TransferManager tm = new TransferManager(dir.toFile(), cs);

        // 1) roundtrip + sha verified, out-of-order chunks
        byte[] d = data(4500); // 5 chunks
        JSONObject r = tm.startReceive("hello.txt", d.length, sha(d));
        String id = r.getString("transferId");
        sendAll(tm, id, d, cs, new int[]{4,0,2,1,3});
        JSONObject st = tm.statusReceive(id);
        check("COMPLETED".equals(st.getString("state")), "roundtrip completes");
        check(st.getBoolean("verified"), "sha verified flag");
        check(Arrays.equals(Files.readAllBytes(dir.resolve("received_files/hello.txt")), d), "content identical");
        check(!new File(dir.toFile(),"incoming_tmp/"+id+".part").exists() && !new File(dir.toFile(),"incoming_tmp/"+id+".meta").exists(), "temp+meta cleaned");

        // 2) wrong sha -> 422, discarded
        byte[] d2 = data(3000);
        String bad = sha(data(10));
        JSONObject r2 = tm.startReceive("bad.bin", d2.length, bad);
        String id2 = r2.getString("transferId");
        int status=0;
        try { sendAll(tm, id2, d2, cs, new int[]{0,1,2}); } catch (FilePolicy.Rejected e) { status=e.status; }
        check(status==422, "sha mismatch -> 422");
        check("FAILED".equals(tm.statusReceive(id2).getString("state")), "state FAILED");
        check(!new File(dir.toFile(),"received_files/bad.bin").exists(), "bad file not saved");

        // 3) policy
        int s3=0; try { tm.startReceive("evil.apk", 10); } catch (FilePolicy.Rejected e){ s3=e.status; }
        check(s3==415, "apk blocked 415");
        s3=0; try { tm.startReceive("invoice.apk.pdf", 10); } catch (FilePolicy.Rejected e){ s3=e.status; }
        check(s3==415, "double extension blocked");
        s3=0; try { tm.startReceive("big.bin", FilePolicy.DEFAULT_MAX_BYTES+1); } catch (FilePolicy.Rejected e){ s3=e.status; }
        check(s3==413, "oversize 413");
        JSONObject tr = tm.startReceive("../../etc/passwd.txt", 0);
        check("passwd.txt".equals(tr.getString("savedAs")), "path traversal sanitized + 0-byte completes");
        JSONObject tr2 = tm.startReceive("..\\..\\win.txt", 0);
        check("win.txt".equals(tr2.getString("savedAs")), "backslash traversal sanitized");
        boolean badSha=false; try { tm.startReceive("x.txt", 5, "nothex"); } catch (IllegalArgumentException e){ badSha=true; }
        check(badSha, "malformed sha rejected");

        // 4) chunk checksum
        byte[] d4 = data(2048);
        String id4 = tm.startReceive("c.txt", d4.length).getString("transferId");
        boolean cm=false; try { tm.writeChunk(id4,0,Arrays.copyOfRange(d4,0,1024), sha(data(3))); } catch (IllegalArgumentException e){ cm=true; }
        check(cm, "bad chunk checksum rejected");
        check(tm.statusReceive(id4).getInt("chunksReceived")==0, "rejected chunk not counted");
        tm.writeChunk(id4,0,Arrays.copyOfRange(d4,0,1024), sha(Arrays.copyOfRange(d4,0,1024)));
        check(tm.statusReceive(id4).getInt("chunksReceived")==1, "good chunk checksum accepted");

        // 5) restart-resume
        byte[] d5 = data(4096); // 4 chunks
        String id5 = tm.startReceive("resume.dat", d5.length, sha(d5)).getString("transferId");
        tm.writeChunk(id5,0,Arrays.copyOfRange(d5,0,1024));
        tm.writeChunk(id5,2,Arrays.copyOfRange(d5,2048,3072));
        TransferManager tm2 = new TransferManager(dir.toFile(), cs); // "app restart"
        JSONObject s5 = tm2.statusReceive(id5);
        check(s5.getInt("chunksReceived")==2 && s5.getInt("nextMissingIndex")==1, "restart: 2 chunks remembered, next missing=1");
        tm2.writeChunk(id5,1,Arrays.copyOfRange(d5,1024,2048));
        tm2.writeChunk(id5,3,Arrays.copyOfRange(d5,3072,4096));
        check("COMPLETED".equals(tm2.statusReceive(id5).getString("state")) && tm2.statusReceive(id5).getBoolean("verified"), "restart: completes + verified");
        check(Arrays.equals(Files.readAllBytes(dir.resolve("received_files/resume.dat")), d5), "restart: content identical");

        // 6) unique destination
        String a1 = tm.startReceive("same.txt", 0).getString("savedAs");
        String a2 = tm.startReceive("same.txt", 0).getString("savedAs");
        check("same.txt".equals(a1) && "same (1).txt".equals(a2), "no overwrite: same (1).txt");

        // 7) send side
        byte[] d7 = data(2500);
        File out = dir.resolve("outbox_f.bin").toFile(); Files.write(out.toPath(), d7);
        JSONObject ss = tm.startSend(out);
        check(ss.getString("sha256").equals(sha(d7)), "send sha256 correct");
        String sid = ss.getString("transferId");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        for(int i=0;i<ss.getInt("totalChunks");i++) bo.write(tm.readChunk(sid,i));
        check(Arrays.equals(bo.toByteArray(), d7), "send chunks reassemble");

        // 8) cancel cleans disk
        String id8 = tm.startReceive("cancel.txt", 2048).getString("transferId");
        tm.cancelReceive(id8);
        check(!new File(dir.toFile(),"incoming_tmp/"+id8+".part").exists() && !new File(dir.toFile(),"incoming_tmp/"+id8+".meta").exists(), "cancel deletes part+meta");

        // 9) pause blocks chunk
        String id9 = tm.startReceive("p.txt", 2048).getString("transferId");
        tm.pauseReceive(id9);
        boolean paused=false; try { tm.writeChunk(id9,0,new byte[1024]); } catch (IllegalStateException e){ paused=true; }
        tm.resumeReceive(id9); tm.writeChunk(id9,0,new byte[1024]);
        check(paused && tm.statusReceive(id9).getInt("chunksReceived")==1, "pause blocks, resume continues");

        System.out.println("\n"+pass+" passed, "+fail+" failed");
        System.exit(fail==0?0:1);
    }
}
