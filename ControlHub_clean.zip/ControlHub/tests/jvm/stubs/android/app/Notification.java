package android.app;
public class Notification { public static class Action {} }
