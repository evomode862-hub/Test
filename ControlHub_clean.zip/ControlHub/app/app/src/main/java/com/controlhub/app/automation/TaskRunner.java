package com.controlhub.app.automation;

import android.content.Context;
import android.os.PowerManager;
import android.util.Log;

import com.controlhub.app.data.AppDatabase;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Automation tasks ko background thread par chalata hai.
 *  - Ek waqt mein sirf EK task (UI-driving task ka interaction lock).
 *  - Line mein wait karne wale tasks priority ke hisaab se chalte hain (bada priority pehle),
 *    barabar priority par jo pehle aaya wo pehle (FIFO).
 *  - Duplicate enqueue safe hai: Engine ke markRunning() guard se terminal/paused/cancelled
 *    task dobara nahi chalta.
 *  Step 6:
 *  - Task chalte waqt PARTIAL_WAKE_LOCK (CPU Doze mein na soye); task khatam hote hi release,
 *    aur 65 minute ki hard timeout (kabhi atka na rahe)
 *  - Engine crash kare to task "failed" mark hota hai (pehle 'running' hi atka rehta tha)
 *  - currentTaskId()/isQueued() — TaskWatchdog inse atke hue tasks pehchanta hai
 */
public class TaskRunner {

    private static final String TAG = "TaskRunner";
    private static final long WAKELOCK_TIMEOUT_MS = 65L * 60 * 1000;
    private static final AtomicLong SEQ = new AtomicLong();
    private static final AutomationEngine ENGINE = new AutomationEngine();
    private static final Set<Long> QUEUED = java.util.Collections.newSetFromMap(new ConcurrentHashMap<Long, Boolean>());
    private static volatile long currentTask = -1;

    public static long currentTaskId() {
        return currentTask;
    }

    public static boolean isQueued(long taskId) {
        return QUEUED.contains(taskId);
    }

    private static class Job implements Runnable, Comparable<Job> {
        final Context app;
        final long taskId;
        final int priority;
        final long seq = SEQ.incrementAndGet();

        Job(Context app, long taskId, int priority) {
            this.app = app;
            this.taskId = taskId;
            this.priority = priority;
        }

        @Override
        public void run() {
            QUEUED.remove(taskId);
            currentTask = taskId;
            PowerManager.WakeLock wl = null;
            try {
                PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "controlhub:task");
                    wl.setReferenceCounted(false);
                    wl.acquire(WAKELOCK_TIMEOUT_MS);
                }
                ENGINE.runTask(app, taskId);
            } catch (Throwable t) {
                Log.e(TAG, "Task " + taskId + " crashed", t);
                try {
                    AppDatabase.getInstance(app).taskDao().markFailed(taskId, System.currentTimeMillis(),
                            "Internal error: " + t.getClass().getSimpleName());
                } catch (Throwable ignored) {
                }
            } finally {
                currentTask = -1;
                if (wl != null && wl.isHeld()) {
                    try {
                        wl.release();
                    } catch (Throwable ignored) {
                    }
                }
            }
        }

        @Override
        public int compareTo(Job o) {
            if (priority != o.priority) return Integer.compare(o.priority, priority); // bada pehle
            return Long.compare(seq, o.seq);
        }
    }

    // execute() (submit nahi) use karte hain, taaki queue mein seedha Job rahe aur Comparable kaam kare
    private static final ThreadPoolExecutor EXECUTOR = new ThreadPoolExecutor(
            1, 1, 0L, TimeUnit.MILLISECONDS, new PriorityBlockingQueue<Runnable>());

    public static void enqueue(Context context, long taskId, int priority) {
        QUEUED.add(taskId);
        EXECUTOR.execute(new Job(context.getApplicationContext(), taskId, priority));
    }

    public static void enqueue(Context context, long taskId) {
        enqueue(context, taskId, 0);
    }
}
