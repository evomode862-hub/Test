package com.controlhub.app.notifications;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import com.controlhub.app.events.EventBus;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Step 4 — Notification observation + inline reply.
 *
 * User ko Settings -> "Notification access" mein Control Hub ko khud ON karna padta hai
 * (Android ka rule; app khud ye permission nahi de sakti).
 *
 * Inline reply = MODE A (background): app ko foreground mein laye bina, notification ke
 * reply-action (RemoteInput) ke zariye jawab bhejna.
 */
public class ControlHubNotificationListener extends NotificationListenerService {

    private static final String TAG = "CHNotifListener";
    private static volatile ControlHubNotificationListener instance;

    public static boolean isConnected() {
        return instance != null;
    }

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        instance = this;
        try {
            StatusBarNotification[] active = getActiveNotifications();
            if (active != null) {
                for (StatusBarNotification sbn : active) {
                    NotificationStore.Item it = toItem(sbn);
                    if (it != null) NotificationStore.put(it);
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not load active notifications", e);
        }
        Log.i(TAG, "Notification listener connected");
        com.controlhub.app.events.PermissionEvents.publish("notification_access", true); // Step 7
    }

    @Override
    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        instance = null;
        NotificationStore.clear();
        Log.i(TAG, "Notification listener disconnected");
        com.controlhub.app.events.PermissionEvents.publish("notification_access", false); // Step 7
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        NotificationStore.Item it = toItem(sbn);
        if (it == null) return;
        NotificationStore.put(it);
        try {
            JSONObject data = new JSONObject();
            data.put("key", it.key);
            data.put("package", it.pkg);
            data.put("hasReply", it.hasReply);
            data.put("postTime", it.postTime);
            if (NotificationStore.isTextExposed(getApplicationContext())) {
                data.put("title", it.title);
                data.put("text", it.text);
            }
            EventBus.publish("notification.posted", data);
        } catch (JSONException ignored) {
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (sbn == null) return;
        NotificationStore.remove(sbn.getKey());
        EventBus.publish("notification.removed", "key", sbn.getKey());
    }

    private NotificationStore.Item toItem(StatusBarNotification sbn) {
        if (sbn == null) return null;
        if (getPackageName().equals(sbn.getPackageName())) return null; // apni notifications ignore

        Notification n = sbn.getNotification();
        if (n == null) return null;

        NotificationStore.Item it = new NotificationStore.Item();
        it.key = sbn.getKey();
        it.pkg = sbn.getPackageName();
        it.postTime = sbn.getPostTime();
        it.category = n.category;
        it.ongoing = (n.flags & Notification.FLAG_ONGOING_EVENT) != 0;
        it.groupSummary = (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0;

        Bundle ex = n.extras;
        if (ex != null) {
            CharSequence t = ex.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence x = ex.getCharSequence(Notification.EXTRA_TEXT);
            it.title = t == null ? "" : t.toString();
            it.text = x == null ? "" : x.toString();
        }

        if (n.actions != null) {
            for (Notification.Action a : n.actions) {
                RemoteInput[] ris = a.getRemoteInputs();
                if (ris != null && ris.length > 0 && a.actionIntent != null) {
                    it.replyAction = a;
                    break;
                }
            }
        }
        it.hasReply = it.replyAction != null;
        return it;
    }

    /**
     * Inline reply bhejo. null = bhej diya gaya (delivery confirm nahi — sirf "system ne intent le liya"),
     * warna error message.
     */
    public static String sendReply(Context context, NotificationStore.Item item, String text) {
        if (item == null || item.replyAction == null) return "notification has no reply action";
        try {
            RemoteInput[] inputs = item.replyAction.getRemoteInputs();
            Bundle results = new Bundle();
            for (RemoteInput ri : inputs) {
                results.putCharSequence(ri.getResultKey(), text);
            }
            Intent fill = new Intent();
            RemoteInput.addResultsToIntent(inputs, fill, results);
            item.replyAction.actionIntent.send(context.getApplicationContext(), 0, fill);
            return null;
        } catch (PendingIntent.CanceledException e) {
            return "reply action is no longer valid (notification expired)";
        } catch (Exception e) {
            return "reply failed: " + e.getMessage();
        }
    }
}
