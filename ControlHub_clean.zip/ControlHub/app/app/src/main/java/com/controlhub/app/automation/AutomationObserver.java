package com.controlhub.app.automation;

import com.controlhub.app.accessibility.ControlHubAccessibilityService;
import com.controlhub.app.accessibility.UiElement;

import java.util.ArrayList;
import java.util.List;

/**
 * Feature #31 — Observe
 * Step 3: foregroundPackage aur behtar "same screen?" signature.
 */
public class AutomationObserver {

    public static class ObservedState {
        public final List<UiElement> elements;
        public final long timestamp;
        public final boolean accessibilityAvailable;
        public final String foregroundPackage;
        private String signature;

        ObservedState(List<UiElement> elements, boolean accessibilityAvailable) {
            this.elements = elements;
            this.timestamp = System.currentTimeMillis();
            this.accessibilityAvailable = accessibilityAvailable;
            String pkg = "";
            for (UiElement el : elements) {
                if (el.packageName != null && !el.packageName.isEmpty()) {
                    pkg = el.packageName;
                    break;
                }
            }
            this.foregroundPackage = pkg;
        }

        private String signature() {
            if (signature == null) {
                StringBuilder sb = new StringBuilder(foregroundPackage).append('#').append(elements.size()).append('#');
                for (UiElement el : elements) {
                    sb.append(el.text).append('|').append(el.contentDesc).append('|').append(el.resourceId).append(';');
                }
                signature = sb.toString();
            }
            return signature;
        }

        /** Do observations "same" hain ya screen change hui */
        public boolean looksSameAs(ObservedState other) {
            if (other == null) return false;
            return this.signature().equals(other.signature());
        }
    }

    public static ObservedState observe() {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) {
            return new ObservedState(new ArrayList<UiElement>(), false);
        }
        List<UiElement> elements = service.readUi();
        return new ObservedState(elements, true);
    }
}
