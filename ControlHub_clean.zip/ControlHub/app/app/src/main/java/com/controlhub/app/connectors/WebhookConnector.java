package com.controlhub.app.connectors;

import android.content.Context;
import android.util.Log;

import com.controlhub.app.events.EventBus;
import com.controlhub.app.security.AuditLogger;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Feature #58 — Connector layer: pehla connector = outbound webhook.
 *
 * Ye EventBus (Stage 11) ka ek aur "listener" hai — bilkul WebSocket client ki tarah — jo
 * events ko ek HTTPS URL par POST kar deta hai (apna Railway endpoint, n8n, Zapier, Make...).
 *
 * Suraksha design:
 *  - destination SIRF phone ka maalik Settings mein set karta hai; remote caller (Claude / MCP)
 *    isko badal nahi sakta, na koi URL de sakta hai — isliye ye phone ko "HTTP proxy" nahi banata
 *  - sirf HTTPS; private/local IP par jaana blocked (WebhookPolicy); redirects follow nahi hote
 *  - rate limit (20/minute), chhota timeout; screenshots ya bade data kabhi nahi bhejta
 *  - is class se koi naya EventBus event publish nahi hota (warna failure -> event -> failure loop)
 *
 * Known limitation: DNS check aur asli connection ke beech ek chhota gap hai (DNS rebinding).
 * URL maalik ne khud set kiya hota hai, isliye ise acceptable maana hai.
 */
public class WebhookConnector implements EventBus.EventSink {

    private static final String TAG = "WebhookConnector";
    private static final int MAX_PER_MINUTE = 20;
    private static final ExecutorService TEST_EXECUTOR = Executors.newSingleThreadExecutor();

    private static WebhookConnector instance;
    private static volatile String lastResult = "no deliveries yet";
    private static volatile long lastFailureLoggedAt = 0;

    public static String getLastResult() {
        return lastResult;
    }

    public static synchronized void start(Context context) {
        if (instance != null) return;
        Context app = context.getApplicationContext();
        if (!WebhookConfig.isConfigured(app)) return;
        instance = new WebhookConnector(app);
        EventBus.register(instance);
    }

    public static synchronized void stop() {
        if (instance != null) {
            EventBus.unregister(instance);
            instance.executor.shutdownNow();
            instance = null;
        }
    }

    public static synchronized void restart(Context context) {
        stop();
        start(context);
    }

    /** Settings ka "Send test event" button — filter aur rate limit bypass karta hai */
    public static void sendTest(Context context) {
        final Context app = context.getApplicationContext();
        final String url = WebhookConfig.getUrl(app);
        if (url.isEmpty()) {
            lastResult = "no URL saved";
            return;
        }
        lastResult = "sending test...";
        TEST_EXECUTOR.execute(() -> {
            try {
                JSONObject event = new JSONObject();
                event.put("type", "webhook.test");
                event.put("timestamp", System.currentTimeMillis());
                event.put("data", new JSONObject().put("message", "Control Hub test event"));
                post(app, url, event);
            } catch (Exception e) {
                recordFailure(app, e);
            }
        });
    }

    // ------------------------------------------------------------------

    private final Context context;
    private final String url;
    private final boolean forwardAll;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final WebhookPolicy.RateLimiter limiter = new WebhookPolicy.RateLimiter(MAX_PER_MINUTE, 60_000);

    private WebhookConnector(Context context) {
        this.context = context;
        this.url = WebhookConfig.getUrl(context);
        this.forwardAll = WebhookConfig.isForwardAll(context);
    }

    /** EventBus ka callback — publisher thread par chalta hai, isliye sirf filter + queue, network nahi */
    @Override
    public void send(String json) {
        try {
            JSONObject event = new JSONObject(json);
            String type = event.optString("type", null);
            if (!WebhookPolicy.shouldForward(type, forwardAll)) return;

            if (!limiter.tryAcquire(System.currentTimeMillis())) {
                lastResult = "rate limited (max " + MAX_PER_MINUTE + "/min) — event dropped";
                return;
            }
            executor.execute(() -> {
                try {
                    post(context, url, event);
                } catch (Exception e) {
                    recordFailure(context, e);
                }
            });
        } catch (Exception e) {
            Log.w(TAG, "Could not queue webhook event: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------

    private static void post(Context context, String urlString, JSONObject event) throws Exception {
        URL url = new URL(urlString);

        // Naam wale host ka asli IP ab check karo (IP-literal wale pehle hi validateUrl mein pakde gaye)
        for (InetAddress address : InetAddress.getAllByName(url.getHost())) {
            if (WebhookPolicy.isBlockedAddress(address)) {
                throw new SecurityException("host resolves to a private/local address — blocked");
            }
        }

        JSONObject payload = new JSONObject();
        payload.put("source", "android_control_hub");
        payload.put("sentAt", System.currentTimeMillis());
        payload.put("event", event);
        byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        try {
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(10000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            try (OutputStream out = conn.getOutputStream()) {
                out.write(bytes);
            }

            int code = conn.getResponseCode();
            try (InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream()) {
                if (in != null) {
                    byte[] buf = new byte[1024];
                    while (in.read(buf) != -1) { /* response body ignore, sirf drain */ }
                }
            }

            String time = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
            if (code >= 200 && code < 300) {
                lastResult = "OK (HTTP " + code + ") at " + time;
            } else {
                lastResult = "FAILED (HTTP " + code + ") at " + time;
                logFailureThrottled(context, "Webhook got HTTP " + code);
            }
        } finally {
            conn.disconnect();
        }
    }

    private static void recordFailure(Context context, Exception e) {
        String time = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        String reason = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
        lastResult = "FAILED (" + reason + ") at " + time;
        logFailureThrottled(context, "Webhook delivery failed: " + reason);
    }

    // Webhook down ho aur events aate rahein to audit log spam na ho — minute mein ek baar
    private static void logFailureThrottled(Context context, String message) {
        long now = System.currentTimeMillis();
        if (now - lastFailureLoggedAt > 60_000) {
            lastFailureLoggedAt = now;
            AuditLogger.warning(context, message);
        }
    }
}
