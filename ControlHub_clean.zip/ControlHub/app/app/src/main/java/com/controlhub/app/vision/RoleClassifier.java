package com.controlhub.app.vision;

import com.controlhub.app.accessibility.UiElement;

/**
 * Feature #37 — Semantic UI labels
 * Android ke technical className (jaise "android.widget.EditText") ko
 * insaan-samajh-sake wale labels mein badalta hai (jaise "text_field").
 * AI ko screen samjhane ke liye raw className se ye labels zyada useful hain.
 */
public class RoleClassifier {

    public static String classify(UiElement element) {
        String className = element.className == null ? "" : element.className.toLowerCase();

        if (element.editable || className.contains("edittext")) {
            return "text_field";
        }
        if (className.contains("checkbox")) {
            return "checkbox";
        }
        if (className.contains("radiobutton")) {
            return "radio_button";
        }
        if (className.contains("switch")) {
            return "toggle";
        }
        if (className.contains("imagebutton")) {
            return "image_button";
        }
        if (className.contains("button")) {
            return "button";
        }
        if (className.contains("imageview")) {
            return "image";
        }
        if (className.contains("textview")) {
            return "text";
        }
        if (className.contains("recyclerview") || className.contains("listview")
                || className.contains("scrollview")) {
            return "scrollable_container";
        }
        if (className.contains("layout") || className.contains("viewgroup")
                || className.contains("framelayout")) {
            return "container";
        }
        if (element.clickable) {
            return "clickable_other";
        }
        return "other";
    }
}
