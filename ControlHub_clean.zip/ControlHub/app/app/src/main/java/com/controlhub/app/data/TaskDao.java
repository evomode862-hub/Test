package com.controlhub.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

/**
 * Step 2: saari status transitions ATOMIC SQL UPDATE hain (WHERE status guard ke saath),
 * taaki API (cancel/pause) aur engine ek doosre ka status overwrite na karein.
 * Return value = kitni rows badli (0 matlab transition allowed nahi thi).
 */
@Dao
public interface TaskDao {

    @Insert
    long insert(TaskEntity task);

    @Update
    void update(TaskEntity task);

    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    List<TaskEntity> getAll();

    @Query("SELECT * FROM tasks WHERE id = :taskId LIMIT 1")
    TaskEntity getById(long taskId);

    @Query("SELECT * FROM tasks WHERE taskUuid = :uuid LIMIT 1")
    TaskEntity getByUuid(String uuid);

    @Query("SELECT * FROM tasks WHERE status = :status ORDER BY createdAt ASC")
    List<TaskEntity> getByStatus(String status);

    @Query("SELECT * FROM tasks WHERE status = :status ORDER BY createdAt DESC LIMIT :limit")
    List<TaskEntity> getRecentByStatus(String status, int limit);

    @Query("SELECT * FROM tasks ORDER BY createdAt DESC LIMIT :limit")
    List<TaskEntity> getRecent(int limit);

    // ---- Step 8: delete / redact / rollback info ----
    @Query("DELETE FROM tasks WHERE id=:id AND status IN ('done','failed','cancelled')")
    int deleteIfFinished(long id);

    /** :olderThan se purane khatam-hue tasks (statusFilter null = teeno terminal status) */
    @Query("DELETE FROM tasks WHERE status IN ('done','failed','cancelled') AND updatedAt < :olderThan AND (:status IS NULL OR status = :status)")
    int purgeFinished(long olderThan, String status);

    @Query("UPDATE tasks SET instructions='[redacted]' WHERE redactWhenDone=1 AND status IN ('done','failed','cancelled') AND instructions != '[redacted]'")
    int redactFinishedFlagged();

    @Query("UPDATE tasks SET startPackage=:pkg, updatedAt=:now WHERE id=:id AND (startPackage IS NULL OR startPackage='')")
    int setStartPackage(long id, String pkg, long now);

    // ---- transitions ----
    @Query("UPDATE tasks SET status='running', updatedAt=:now WHERE id=:id AND status IN ('pending','running')")
    int markRunning(long id, long now);

    @Query("UPDATE tasks SET status='done', updatedAt=:now, lastError=NULL WHERE id=:id AND status='running'")
    int markDone(long id, long now);

    @Query("UPDATE tasks SET status='failed', updatedAt=:now, lastError=:error WHERE id=:id AND status IN ('pending','running')")
    int markFailed(long id, long now, String error);

    @Query("UPDATE tasks SET status='cancelled', updatedAt=:now WHERE id=:id AND status IN ('pending','running','paused')")
    int markCancelled(long id, long now);

    @Query("UPDATE tasks SET status='paused', updatedAt=:now WHERE id=:id AND status IN ('pending','running')")
    int markPaused(long id, long now);

    @Query("UPDATE tasks SET status='pending', updatedAt=:now WHERE id=:id AND status='paused'")
    int markResumed(long id, long now);

    /** failed task ko dobara chalana — currentStep se (fromStart=false) ya shuru se */
    @Query("UPDATE tasks SET status='pending', updatedAt=:now, lastError=NULL, deadlineAt=:newDeadline WHERE id=:id AND status='failed'")
    int markRetry(long id, long now, long newDeadline);

    @Query("UPDATE tasks SET status='pending', updatedAt=:now, lastError=NULL, deadlineAt=:newDeadline, currentStep=0 WHERE id=:id AND status='failed'")
    int markRetryFromStart(long id, long now, long newDeadline);

    /** process kill ke baad: stale 'running' -> 'pending' (recovery) */
    @Query("UPDATE tasks SET status='pending', recoveryCount=recoveryCount+1, updatedAt=:now WHERE id=:id AND status='running'")
    int markInterrupted(long id, long now);

    @Query("UPDATE tasks SET currentStep=:step, updatedAt=:now WHERE id=:id")
    void updateStep(long id, int step, long now);

    @Query("UPDATE tasks SET retryCount=retryCount+1, lastError=:error, updatedAt=:now WHERE id=:id")
    void incrementRetry(long id, long now, String error);

    /** Emergency Stop: har active (pending/running/paused) task ek saath cancel */
    @Query("UPDATE tasks SET status='cancelled', updatedAt=:now WHERE status IN ('pending','running','paused')")
    int cancelAllActive(long now);
}
