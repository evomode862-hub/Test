package com.controlhub.app.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.controlhub.app.R;
import com.controlhub.app.api.LocalApiServer;
import com.controlhub.app.automation.TaskRecovery;
import com.controlhub.app.automation.TaskWatchdog;
import com.controlhub.app.connectors.WebhookConnector;
import com.controlhub.app.events.EventWebSocketServer;
import com.controlhub.app.relay.RelayClient;
import com.controlhub.app.sdk.ModuleBootstrap;

import java.io.IOException;

/**
 * Feature #27 — Foreground Service
 * Feature #28 — Service start/stop control (app band hone ke baad bhi chalti rahe)
 *
 * Ye service Local API Server (Feature #19) ko Activity se independent bana deti hai.
 * Android ka rule: background mein "chup-chaap" chalna allowed nahi — isliye ek
 * permanent (ongoing) notification dikhani zaroori hai jab tak service chal rahi hai.
 */
public class ControlHubForegroundService extends Service {

    private static final String TAG = "ControlHubService";
    private static final String CHANNEL_ID = "control_hub_service_channel";
    private static final int NOTIFICATION_ID = 1001;

    private static volatile boolean running = false;

    public static final String ACTION_RESTART_SERVERS = "com.controlhub.app.RESTART_SERVERS";

    /** LAN/loopback setting badalne ke baad servers dobara chalao */
    public static void restartServers(Context context) {
        Intent i = new Intent(context, ControlHubForegroundService.class);
        i.setAction(ACTION_RESTART_SERVERS);
        androidx.core.content.ContextCompat.startForegroundService(context, i);
    }

    private LocalApiServer apiServer;
    private EventWebSocketServer eventServer; // Feature #50

    public static boolean isRunning() {
        return running;
    }

    /** Feature #28 — service ko start karne ka standard tareeka (kahin se bhi call ho sakta hai) */
    public static void start(Context context) {
        Intent intent = new Intent(context, ControlHubForegroundService.class);
        ContextCompat.startForegroundService(context, intent);
    }

    /** Feature #28 — service ko stop karna */
    public static void stop(Context context) {
        Intent intent = new Intent(context, ControlHubForegroundService.class);
        context.stopService(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        com.controlhub.app.security.EmergencyStopManager.init(this); // Step 6: persisted stop flag
        createNotificationChannel();
        ModuleBootstrap.registerAll(); // Feature #57 — SDK modules
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Step 8: Settings mein LAN switch badalne par servers naye binding ke saath restart
        if (intent != null && ACTION_RESTART_SERVERS.equals(intent.getAction())) {
            if (apiServer != null) {
                apiServer.stop();
                apiServer = null;
            }
            if (eventServer != null) {
                eventServer.stop();
                eventServer = null;
            }
        }
        // Step 6: Android 14+ par "specialUse" type — dataSync par Android 15 mein ~6 ghante ka time limit hai,
        // jo 24/7 service ko maar deta. (Play Store par specialUse ka declaration chahiye; sideload par nahi.)
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification());
        }

        if (apiServer == null || !apiServer.isAlive()) {
            try {
                apiServer = new LocalApiServer(this);
                apiServer.start(60000, false);
                running = true;
                Log.i(TAG, "Local API Server started on port " + LocalApiServer.PORT);
            } catch (IOException e) {
                Log.e(TAG, "Failed to start Local API Server in foreground service", e);
            }
        }

        // Feature #50 — live event stream (WebSocket) bhi saath mein chalu karo
        if (eventServer == null || !eventServer.isAlive()) {
            try {
                eventServer = new EventWebSocketServer(this);
                eventServer.start(60000, false);
                Log.i(TAG, "Event WebSocket server started on port " + EventWebSocketServer.PORT);
            } catch (IOException e) {
                Log.e(TAG, "Failed to start Event WebSocket server", e);
            }
        }

        // Feature #54/#55 — relay (Settings mein configured ho tabhi connect hota hai)
        RelayClient.start(this);

        // Feature #58 — outbound webhook connector (Settings mein URL set ho tabhi chalta hai)
        WebhookConnector.start(this);

        // Step 2 — interrupted/pending tasks ko checkpoint se resume karo (process mein ek hi baar)
        TaskRecovery.recoverOnce(this);

        // Step 6 — atke hue tasks ka watchdog + audit log retention
        TaskWatchdog.start(this);

        // Feature #28 — agar Android system ne resource-crunch mein service ko
        // beech mein mar diya, START_STICKY isse dobara khud restart karne ki
        // koshish karayega (basic-level auto-recovery, Feature #30 se related)
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (apiServer != null && apiServer.isAlive()) {
            apiServer.stop();
        }
        if (eventServer != null && eventServer.isAlive()) {
            eventServer.stop();
        }
        RelayClient.stop();
        WebhookConnector.stop();
        running = false;
        Log.i(TAG, "Control Hub Foreground Service stopped");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null; // Feature #27 — ye ek "started service" hai, bound service nahi
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Control Hub Background Service",
                    NotificationManager.IMPORTANCE_LOW // low = koi sound/vibration nahi, sirf silent status
            );
            channel.setDescription("Local API Server background mein chalte rehne ke liye");

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Control Hub")
                .setContentText("API Server running on port " + LocalApiServer.PORT)
                .setSmallIcon(R.drawable.ic_notification)
                .setOngoing(true) // Feature #27 — user isko swipe karke hata na sake, jab tak service chal rahi hai
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }
}
