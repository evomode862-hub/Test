package com.controlhub.app.automation;

import com.controlhub.app.accessibility.UiElement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Step 3 — Selector: screen par element dhoondhne ka tareeka (fixed coordinates par nahi).
 *
 * Syntax (ek selector = constraints " & " se jude; alternates " || " se):
 *   id=<resource-id>        (poora ya sirf aakhri hissa, jaise "send")
 *   desc=<content description>
 *   text=<exact text>       has=<text contains>     (bina key ka plain text = has)
 *   cls=<class name>        (jaise EditText / Button)
 *   within=<container text> (hierarchy: element us text wale container ke andar ho)
 *   nth=<0-based index>     (ek se zyada match par kaunsa)
 *   xy=<x>,<y>              (aakhri fallback — bounded coordinate)
 *
 * Example:  tap:id=send || desc=Send || text=Send & within=Chat || xy=980,2150
 *
 * Priority (spec): resource-id -> content-desc -> text/role -> hierarchy -> coordinate.
 * Har match ke saath confidence (0..1) aata hai. version/expiresAt metadata adapters ke liye hai
 * (expiresAt guzar jaye to selector use nahi hota).
 */
public class Selector {

    public String id, desc, text, has, cls, within;
    public int nth = -1;
    public int x = -1, y = -1;
    public int version = 1;
    public long expiresAt = 0; // 0 = kabhi expire nahi

    public boolean isCoordinate() {
        return x >= 0 && y >= 0 && id == null && desc == null && text == null && has == null && cls == null && within == null;
    }

    public boolean isExpired() {
        return expiresAt > 0 && System.currentTimeMillis() > expiresAt;
    }

    /** 0 = sabse pehle (resource-id) ... 4 = coordinate */
    public int priority() {
        if (id != null) return 0;
        if (desc != null) return 1;
        if (text != null || has != null || cls != null) return 2;
        if (within != null) return 3;
        return 4;
    }

    public String kind() {
        switch (priority()) {
            case 0: return "id";
            case 1: return "desc";
            case 2: return "text";
            case 3: return "hierarchy";
            default: return "xy";
        }
    }

    // -------------------- parsing --------------------
    public static List<Selector> parseAlternates(String raw) {
        List<Selector> out = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            throw new IllegalArgumentException("Empty selector");
        }
        for (String alt : raw.trim().split("\\s\\|\\|\\s")) {
            out.add(parseOne(alt.trim()));
        }
        return out;
    }

    private static final Set<String> KEYS = new HashSet<>();
    static {
        Collections.addAll(KEYS, "id", "desc", "text", "has", "cls", "within", "nth", "xy");
    }

    public static Selector parseOne(String raw) {
        Selector s = new Selector();
        if (raw.isEmpty()) throw new IllegalArgumentException("Empty selector");
        for (String part : raw.split("\\s&\\s")) {
            String c = part.trim();
            int eq = c.indexOf('=');
            String key = eq > 0 ? c.substring(0, eq).trim().toLowerCase() : null;
            if (key != null && KEYS.contains(key)) {
                String v = c.substring(eq + 1).trim();
                if (v.isEmpty()) throw new IllegalArgumentException("Empty value for '" + key + "'");
                switch (key) {
                    case "id": s.id = v; break;
                    case "desc": s.desc = v; break;
                    case "text": s.text = v; break;
                    case "has": s.has = v; break;
                    case "cls": s.cls = v; break;
                    case "within": s.within = v; break;
                    case "nth":
                        try { s.nth = Integer.parseInt(v); } catch (NumberFormatException e) {
                            throw new IllegalArgumentException("nth must be a number");
                        }
                        break;
                    case "xy":
                        String[] xy = v.split(",");
                        try {
                            s.x = Integer.parseInt(xy[0].trim());
                            s.y = Integer.parseInt(xy[1].trim());
                        } catch (Exception e) {
                            throw new IllegalArgumentException("xy must be like xy=540,1200");
                        }
                        break;
                    default: break;
                }
            } else {
                s.has = c; // plain text
            }
        }
        return s;
    }

    // -------------------- matching --------------------
    public static class Match {
        public final UiElement element; // coordinate fallback mein null
        public final Selector selector;
        public final double confidence;
        public final int x, y;

        Match(UiElement element, Selector selector, double confidence) {
            this.element = element;
            this.selector = selector;
            this.confidence = confidence;
            this.x = element != null ? element.centerX() : selector.x;
            this.y = element != null ? element.centerY() : selector.y;
        }
    }

    private static boolean eq(String a, String b) {
        return a != null && b != null && a.equalsIgnoreCase(b);
    }

    private static boolean has(String a, String b) {
        return a != null && b != null && a.toLowerCase().contains(b.toLowerCase());
    }

    /** 0 = match nahi, warna confidence */
    double score(UiElement el, List<UiElement> all) {
        double best = 0;
        boolean identifying = false;

        if (id != null) {
            identifying = true;
            String rid = el.resourceId == null ? "" : el.resourceId;
            double c;
            if (rid.equalsIgnoreCase(id) || rid.toLowerCase().endsWith("/" + id.toLowerCase())) c = 1.0;
            else if (!rid.isEmpty() && rid.toLowerCase().contains(id.toLowerCase())) c = 0.7;
            else return 0;
            best = Math.max(best, c);
        }
        if (desc != null) {
            identifying = true;
            double c;
            if (eq(el.contentDesc, desc)) c = 0.9;
            else if (has(el.contentDesc, desc)) c = 0.7;
            else return 0;
            best = Math.max(best, c);
        }
        if (text != null) {
            identifying = true;
            if (!eq(el.text, text)) return 0;
            best = Math.max(best, 0.8);
        }
        if (has != null) {
            identifying = true;
            // plain text: text ya content-desc, dono mein dhoondo
            if (!(has(el.text, has) || has(el.contentDesc, has))) return 0;
            best = Math.max(best, 0.6);
        }
        if (cls != null) {
            String c = el.className == null ? "" : el.className;
            if (!(c.equalsIgnoreCase(cls) || c.toLowerCase().endsWith("." + cls.toLowerCase()))) return 0;
            if (!identifying) best = Math.max(best, 0.4);
        }
        if (within != null) {
            if (!hasAncestorWith(el, all, within)) return 0;
            if (!identifying && cls == null) best = Math.max(best, 0.3);
        }
        return best;
    }

    private static boolean hasAncestorWith(UiElement el, List<UiElement> all, String needle) {
        int pid = el.parentId;
        int guard = 0;
        while (pid >= 0 && pid < all.size() && guard++ < 30) {
            UiElement p = all.get(pid);
            if (has(p.text, needle) || has(p.contentDesc, needle)) return true;
            pid = p.parentId;
        }
        return false;
    }

    /** text wala node aksar clickable nahi hota — nearest clickable parent par click karo */
    private static UiElement toClickTarget(UiElement el, List<UiElement> all) {
        if (el.clickable) return el;
        int pid = el.parentId;
        int guard = 0;
        while (pid >= 0 && pid < all.size() && guard++ < 6) {
            UiElement p = all.get(pid);
            if (p.clickable) return p;
            pid = p.parentId;
        }
        return el;
    }

    /**
     * Saare candidates, priority order mein (id -> desc -> text -> hierarchy -> xy),
     * har priority ke andar confidence ke hisaab se. Duplicate elements hata diye jaate hain.
     */
    public static List<Match> resolveAll(List<UiElement> elements, List<Selector> selectors) {
        List<Selector> sorted = new ArrayList<>(selectors);
        Collections.sort(sorted, new Comparator<Selector>() {
            @Override
            public int compare(Selector a, Selector b) {
                return Integer.compare(a.priority(), b.priority()); // stable
            }
        });

        List<Match> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Selector sel : sorted) {
            if (sel.isExpired()) continue;
            if (sel.isCoordinate()) {
                out.add(new Match(null, sel, 0.2));
                continue;
            }
            List<Match> local = new ArrayList<>();
            for (UiElement el : elements) {
                double c = sel.score(el, elements);
                if (c > 0) local.add(new Match(el, sel, c));
            }
            if (sel.nth >= 0) {
                List<Match> picked = new ArrayList<>();
                if (sel.nth < local.size()) picked.add(local.get(sel.nth));
                local = picked;
            } else {
                Collections.sort(local, new Comparator<Match>() {
                    @Override
                    public int compare(Match a, Match b) {
                        return Double.compare(b.confidence, a.confidence); // stable: doc order barqarar
                    }
                });
            }
            for (Match m : local) {
                UiElement target = toClickTarget(m.element, elements);
                String key = target.resourceId + "|" + target.bounds.toShortString() + "|" + target.className;
                if (seen.add(key)) {
                    out.add(new Match(target, sel, m.confidence));
                }
            }
        }
        return out;
    }
}
