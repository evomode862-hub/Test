package com.controlhub.app.relay;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;

import com.controlhub.app.api.ApiTokenManager;
import com.controlhub.app.api.LocalApiServer;
import com.controlhub.app.security.AuditLogger;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * Feature #54/#55 — Relay client
 *
 * Phone khud Railway backend se OUTBOUND connect karta hai (phones NAT ke peeche
 * hote hain, unka seedha public URL nahi hota). Backend jab MCP tool call receive
 * karta hai, wo yahan request bhejta hai; ye class use phone ke apne Local API
 * (127.0.0.1:8080) pe chalati hai aur jawab wapas bhejti hai.
 *
 * SECURITY: relay Local API ko ek normal HTTP client ki tarah call karta hai —
 * isliye Stage 8 ki saari checks (token, scope ON/OFF, HIGH_RISK confirm:true,
 * audit log, Emergency Stop) apne aap lagu rehti hain. Relay unhe bypass nahi karta.
 * Upar se ek allow-list hai: sirf wahi paths jo Local API ke documented endpoints hain.
 */
public class RelayClient {

    public enum State { STOPPED, CONNECTING, CONNECTED, WAITING_RETRY }

    private static final String TAG = "RelayClient";
    private static final int MAX_IMAGE_EDGE = 1600;   // screenshot ko is se bada nahi bhejte
    private static final int JPEG_QUALITY = 70;

    // Sirf ye "METHOD path" allowed hain (query string path se pehle hata di jaati hai)
    private static final Set<String> ALLOWED = new HashSet<>(Arrays.asList(
            "GET /capabilities", "GET /apps", "GET /app/status", "GET /ui/read",
            "GET /scene", "GET /screenshot",
            "POST /app/launch", "POST /app/stop", "POST /ui/click", "POST /ui/type",
            "POST /ui/scroll", "POST /ui/back", "POST /ui/home",
            "POST /ui/long_click", "POST /ui/key", "GET /device/state",
            "POST /file/send/start", "GET /file/send/chunk", "GET /file/send/status",
            "POST /file/send/pause", "POST /file/send/resume", "POST /file/send/cancel",
            "POST /file/receive/start", "POST /file/receive/chunk", "GET /file/receive/status",
            "POST /file/receive/pause", "POST /file/receive/resume", "POST /file/receive/cancel",
            // Step 1-5: tasks, notifications, adapters, emergency stop (backend MCP tools inhe use karte hain)
            // NOTE: /auth/* jaanbujh kar yahan NAHI hai — remote agent token mint/revoke nahi kar sakta
            "POST /task/create", "GET /task/status", "GET /task/list", "POST /task/pause",
            "POST /task/resume", "POST /task/retry", "POST /task/cancel", "POST /task/delete", "POST /task/purge",
            "GET /notifications", "POST /notification/reply", "GET /adapters",
            "POST /emergency/stop", "GET /emergency/status"));

    // Feature #57 — SDK modules: POST /x/<module>/<capability> (naam-format registry jaisa hi)
    private static final Pattern MODULE_PATH =
            Pattern.compile("^/x/[a-z][a-z0-9_]{1,31}/[a-z][a-z0-9_]{1,31}$");

    private static volatile State state = State.STOPPED;
    private static volatile String lastError = "";
    private static RelayClient instance;

    public static State getState() { return state; }
    public static String getLastError() { return lastError; }

    public static synchronized void start(Context context) {
        if (instance != null) return;
        Context app = context.getApplicationContext();
        if (!RelayConfig.isConfigured(app)) {
            state = State.STOPPED;
            return;
        }
        instance = new RelayClient(app);
        instance.connect();
    }

    public static synchronized void stop() {
        if (instance != null) {
            instance.shutdown();
            instance = null;
        }
        state = State.STOPPED;
    }

    /** Settings badalne ke baad naye config ke saath dobara connect */
    public static synchronized void restart(Context context) {
        stop();
        start(context);
    }

    // ------------------------------------------------------------------

    private final Context context;
    private final OkHttpClient http = new OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)   // NAT/proxy idle-timeout se bachne ke liye
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build();
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private volatile WebSocket socket;
    private volatile boolean stopped = false;
    private int attempt = 0;

    private RelayClient(Context context) {
        this.context = context;
    }

    private void connect() {
        if (stopped) return;
        state = State.CONNECTING;

        String url = RelayConfig.getUrl(context);
        String token = RelayConfig.getDeviceToken(context);
        if (url.isEmpty() || token.isEmpty()) {
            state = State.STOPPED;
            return;
        }

        Request request = new Request.Builder()
                .url(url.replaceFirst("(?i)^wss://", "https://"))   // OkHttp WebSocket ke liye https:// scheme leta hai
                .header("Authorization", "Bearer " + token)
                .build();

        socket = http.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket ws, Response response) {
                attempt = 0;
                lastError = "";
                state = State.CONNECTED;
                Log.i(TAG, "Relay connected");
                AuditLogger.info(context, "Relay connected to backend");
            }

            @Override
            public void onMessage(WebSocket ws, String text) {
                // Reader thread ko block mat karo (screenshot jaisi requests slow ho sakti hain)
                workers.execute(() -> handleRequest(ws, text));
            }

            @Override
            public void onClosed(WebSocket ws, int code, String reason) {
                Log.i(TAG, "Relay closed: " + code);
                scheduleReconnect("closed (" + code + ")");
            }

            @Override
            public void onFailure(WebSocket ws, Throwable t, Response response) {
                String why = response != null ? "HTTP " + response.code() : String.valueOf(t.getMessage());
                Log.w(TAG, "Relay failure: " + why);
                scheduleReconnect(why);
            }
        });
    }

    private void scheduleReconnect(String reason) {
        if (stopped) return;
        lastError = reason;
        state = State.WAITING_RETRY;
        long delaySec = Math.min(30, 2L << Math.min(attempt, 4));   // 2,4,8,16,30,30...
        attempt++;
        try {
            scheduler.schedule(this::connect, delaySec, TimeUnit.SECONDS);
        } catch (Exception ignored) {
            // scheduler shutdown ho chuka hai (stop() ke baad) — kuch nahi karna
        }
    }

    private void shutdown() {
        stopped = true;
        WebSocket ws = socket;
        if (ws != null) {
            ws.close(1000, "client stopping");
        }
        scheduler.shutdownNow();
        workers.shutdownNow();
        AuditLogger.info(context, "Relay stopped");
    }

    // ------------------------------------------------------------------

    private void handleRequest(WebSocket ws, String text) {
        String id = null;
        try {
            JSONObject msg = new JSONObject(text);
            if (!"request".equals(msg.optString("type"))) return;

            id = msg.getString("id");
            String method = msg.optString("method", "GET");
            String path = msg.optString("path", "");
            String body = msg.isNull("body") ? null : msg.optJSONObject("body") != null
                    ? msg.getJSONObject("body").toString() : null;

            if (!isPathAllowed(method, path)) {
                send(ws, errorResponse(id, 403, "Path not allowed by relay: " + method + " " + path));
                return;
            }

            send(ws, callLocalApi(id, method, path, body));
        } catch (Exception e) {
            Log.e(TAG, "Error handling relay request", e);
            if (id != null) {
                send(ws, errorResponse(id, 500, "Relay error: " + e.getMessage()));
            }
        }
    }

    static boolean isPathAllowed(String method, String pathWithQuery) {
        if (pathWithQuery == null || !pathWithQuery.startsWith("/")) return false;
        if (pathWithQuery.contains("..") || pathWithQuery.contains("\r") || pathWithQuery.contains("\n")
                || pathWithQuery.contains(" ")) return false;
        String path = pathWithQuery;
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);
        if (method.equalsIgnoreCase("POST") && MODULE_PATH.matcher(path).matches()) {
            return true;
        }
        return ALLOWED.contains(method.toUpperCase() + " " + path);
    }

    private JSONObject callLocalApi(String id, String method, String path, String body) throws Exception {
        URL url = new URL("http://127.0.0.1:" + LocalApiServer.PORT + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        try {
            conn.setConnectTimeout(2000);
            conn.setReadTimeout(20000);
            conn.setRequestMethod(method.toUpperCase());
            conn.setRequestProperty("X-Auth-Token", ApiTokenManager.getOrCreateToken(context));
            // Step 6: har relay request ka apna unique id idempotency key banta hai (replay/retry par dobara execute nahi hoga).
            // Caller body mein "idempotencyKey" de to wahi use hota hai (server body wali key ko tarjeeh deta hai).
            conn.setRequestProperty("X-Idempotency-Key", "relay-" + id);

            if ("POST".equalsIgnoreCase(method)) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                byte[] bytes = (body == null ? "{}" : body).getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = conn.getOutputStream()) {
                    out.write(bytes);
                }
            }

            int code = conn.getResponseCode();
            InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            byte[] data = readAll(in);
            String contentType = conn.getContentType() == null ? "" : conn.getContentType();

            JSONObject resp = new JSONObject();
            resp.put("type", "response");
            resp.put("id", id);
            resp.put("status", code);

            if (code < 400 && contentType.startsWith("image/")) {
                int[] opts = screenshotOptions(path); // Step 8: ?maxEdge=&quality= (live view ke liye chhota/halka frame)
                byte[] jpeg = toDownscaledJpeg(data, opts[0], opts[1]);
                if (jpeg == null) {
                    return errorResponse(id, 500, "Could not process screenshot image");
                }
                resp.put("contentType", "image/jpeg");
                resp.put("bodyBase64", Base64.encodeToString(jpeg, Base64.NO_WRAP));
            } else {
                resp.put("contentType", contentType);
                resp.put("body", new String(data, StandardCharsets.UTF_8));
            }
            return resp;
        } finally {
            conn.disconnect();
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        if (in == null) return new byte[0];
        try (InputStream is = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    /** PNG screenshot bahut bada hota hai (MBs) — MCP ke liye chhota JPEG bhejte hain */
    /** "/screenshot?maxEdge=720&quality=55" -> {maxEdge, quality}, clamp: edge 240..1600, quality 25..90 */
    static int[] screenshotOptions(String path) {
        int edge = MAX_IMAGE_EDGE;
        int quality = JPEG_QUALITY;
        int q = path == null ? -1 : path.indexOf('?');
        if (q >= 0) {
            for (String kv : path.substring(q + 1).split("&")) {
                String[] p = kv.split("=", 2);
                if (p.length != 2) continue;
                try {
                    if (p[0].equals("maxEdge")) edge = Math.max(240, Math.min(MAX_IMAGE_EDGE, Integer.parseInt(p[1])));
                    if (p[0].equals("quality")) quality = Math.max(25, Math.min(90, Integer.parseInt(p[1])));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return new int[]{edge, quality};
    }

    private static byte[] toDownscaledJpeg(byte[] imageBytes, int maxEdge, int jpegQuality) {
        Bitmap bmp = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
        if (bmp == null) return null;

        int longest = Math.max(bmp.getWidth(), bmp.getHeight());
        if (longest > maxEdge) {
            float scale = (float) maxEdge / longest;
            Bitmap scaled = Bitmap.createScaledBitmap(bmp,
                    Math.max(1, Math.round(bmp.getWidth() * scale)),
                    Math.max(1, Math.round(bmp.getHeight() * scale)), true);
            bmp.recycle();
            bmp = scaled;
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, jpegQuality, out);
        bmp.recycle();
        return out.toByteArray();
    }

    private static JSONObject errorResponse(String id, int status, String message) {
        JSONObject resp = new JSONObject();
        try {
            resp.put("type", "response");
            resp.put("id", id);
            resp.put("status", status);
            resp.put("contentType", "application/json");
            resp.put("body", new JSONObject().put("error", message).toString());
        } catch (Exception ignored) {
        }
        return resp;
    }

    private void send(WebSocket ws, JSONObject json) {
        ws.send(json.toString());
    }
}
