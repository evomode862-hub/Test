package com.controlhub.app.sdk;

import android.util.Log;

import com.controlhub.app.sdk.modules.SampleModule;

/**
 * Feature #57 — Saare built-in SDK modules yahin register hote hain.
 * Naya module banaya? Bas yahan ek line jodo. Service start par ek baar chalta hai;
 * dobara call karne par bhi safe hai (duplicate ignore ho jaata hai).
 */
public final class ModuleBootstrap {

    private static final String TAG = "ModuleBootstrap";

    private ModuleBootstrap() {
    }

    public static void registerAll() {
        registerSafely(new SampleModule());
        // registerSafely(new MyNewModule());   // <- naya module aise jodo
    }

    private static void registerSafely(CapabilityModule module) {
        try {
            if (CapabilityRegistry.register(module)) {
                Log.i(TAG, "Registered module: " + module.name() + " v" + module.version());
            }
        } catch (IllegalArgumentException e) {
            // ek kharab module poori app ko na gira de — skip karo, log karo
            Log.e(TAG, "Module rejected: " + e.getMessage());
        }
    }
}
