package com.controlhub.app.apps;

import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Process;
import android.util.Log;

import com.controlhub.app.data.AppDatabase;
import com.controlhub.app.data.AppEntity;
import com.controlhub.app.events.EventBus;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Feature #6 — Installed Apps Manager
 * Feature #8 — App Launcher
 * Feature #9 — App Stop/Switch
 * Feature #10 — App status check
 *
 * IMPORTANT (honest technical note, so isko aage use karte waqt galatfehmi na ho):
 * Android security model kisi bhi third-party app ko doosri apps ko "force stop"
 * karne ki full permission nahi deta (wo sirf Settings > Apps se, ya device-owner/
 * admin app se hota hai). isliye stopApp() sirf "best-effort" hai — background
 * process ko kill karne ki request bhejta hai, guaranteed stop nahi.
 *
 * Isi tarah isAppRunning() sahi result tabhi dega jab user ne "Usage Access"
 * permission manually Settings mein on ki ho (ye ek special permission hai,
 * normal runtime dialog se nahi milti) — warna Android privacy restriction ki
 * wajah se ye hamesha "unknown/false" degi.
 */
public class InstalledAppsManager {

    private static final String TAG = "InstalledAppsManager";
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    /**
     * Feature #6 — saari "launchable" apps (jo user khol sakta hai) ki list nikaalta hai.
     * Query ye <queries> manifest declaration ki wajah se kaam karti hai (Android 11+ rule).
     */
    public static List<AppEntity> queryInstalledApps(Context context) {
        List<AppEntity> result = new ArrayList<>();
        PackageManager pm = context.getPackageManager();

        Intent launcherIntent = new Intent(Intent.ACTION_MAIN);
        launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> resolvedApps = pm.queryIntentActivities(launcherIntent, 0);
        long now = System.currentTimeMillis();

        for (ResolveInfo info : resolvedApps) {
            ApplicationInfo appInfo = info.activityInfo.applicationInfo;
            String packageName = appInfo.packageName;
            String label = pm.getApplicationLabel(appInfo).toString();
            boolean running = isAppRunning(context, packageName);

            result.add(new AppEntity(packageName, label, running, now));
        }

        return result;
    }

    /**
     * Feature #6 — nikaali hui list ko Room database mein save/update karta hai.
     * Background thread pe chalana chahiye (Room main-thread query allow nahi karta).
     */
    public static void syncToDatabase(Context context) {
        executor.execute(() -> {
            List<AppEntity> apps = queryInstalledApps(context);
            AppDatabase db = AppDatabase.getInstance(context);
            for (AppEntity app : apps) {
                db.appDao().upsert(app);
            }
            Log.i(TAG, "Synced " + apps.size() + " apps to database");
        });
    }

    /**
     * Feature #8 — App Launcher: kisi app ko package name se khol dena.
     * @return true agar launch intent mila aur bheja gaya, false agar app launchable nahi hai
     */
    public static boolean launchApp(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        Intent launchIntent = pm.getLaunchIntentForPackage(packageName);

        if (launchIntent == null) {
            Log.w(TAG, "No launch intent found for: " + packageName);
            return false;
        }

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(launchIntent);
        EventBus.publish("app.started", "package", packageName); // Feature #51
        return true;
    }

    /**
     * Feature #9 — App Stop (best-effort, see class-level note).
     * killBackgroundProcesses() sirf tab kaam karta hai jab target app background mein
     * ho aur system usse "killable" maanta ho — foreground/active app ko force-close
     * karna kisi bhi normal app ke liye Android par possible nahi hai.
     */
    public static void stopApp(Context context, String packageName) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null) {
            am.killBackgroundProcesses(packageName);
            Log.i(TAG, "Requested background-kill for: " + packageName + " (best-effort)");
            EventBus.publish("app.stopped", "package", packageName); // Feature #51 (best-effort stop request)
        }
    }

    /**
     * Feature #9 — App Switch: launch hi switch ka kaam karta hai (Android app ko
     * foreground mein le aata hai agar wo already background mein chal rahi ho).
     */
    public static boolean switchToApp(Context context, String packageName) {
        return launchApp(context, packageName);
    }

    /**
     * Feature #10 — App status check.
     * Accurate result ke liye "Usage Access" special permission chahiye
     * (Settings > Apps > Special access > Usage access mein user ko khud on karni hoti hai).
     * Permission na ho to ye hamesha false return karega — galat "running" result dikhane
     * se behtar hai honestly false dena.
     */
    public static boolean isAppRunning(Context context, String packageName) {
        if (!hasUsageAccessPermission(context)) {
            return false;
        }

        UsageStatsManager usm = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        if (usm == null) {
            return false;
        }

        long end = System.currentTimeMillis();
        long start = end - 1000 * 10; // pichle 10 seconds ka window — "abhi active hai" check ke liye

        List<android.app.usage.UsageStats> stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, start, end);

        if (stats == null) {
            return false;
        }

        for (android.app.usage.UsageStats stat : stats) {
            if (stat.getPackageName().equals(packageName) && stat.getLastTimeUsed() >= start) {
                return true;
            }
        }
        return false;
    }

    /** Feature #10 helper — Usage Access permission diya hua hai ya nahi, check karta hai. */
    public static boolean hasUsageAccessPermission(Context context) {
        AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        if (appOps == null) return false;

        int mode = appOps.unsafeCheckOpNoThrow(
                "android:get_usage_stats",
                Process.myUid(),
                context.getPackageName());

        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /** Step 8: phone ka home-screen (launcher) package — rollback mein "home par wapas" pehchanne ke liye */
    public static String getLauncherPackage(android.content.Context context) {
        android.content.Intent home = new android.content.Intent(android.content.Intent.ACTION_MAIN);
        home.addCategory(android.content.Intent.CATEGORY_HOME);
        android.content.pm.ResolveInfo ri = context.getPackageManager()
                .resolveActivity(home, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null ? ri.activityInfo.packageName : "";
    }
}
