package com.controlhub.app.sdk.modules;

import android.os.Build;

import com.controlhub.app.sdk.Capability;
import com.controlhub.app.sdk.CapabilityModule;
import com.controlhub.app.security.ApiScope;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

/**
 * Feature #57 — SDK ka example module. Naya module likhte waqt isko template ki tarah copy karo.
 *
 *   POST /x/sample/echo         body: {"arguments": {"text": "hi"}}
 *   POST /x/sample/device_info  body: {"arguments": {}}
 *
 * Dono READ scope mein hain (koi side-effect nahi), isliye confirm:true nahi chahiye.
 * Agar capability kuch badalti/bhejti hai to scope WRITE ya HIGH_RISK rakho — HIGH_RISK par
 * server khud confirm:true maangta hai.
 */
public class SampleModule implements CapabilityModule {

    @Override
    public String name() {
        return "sample";
    }

    @Override
    public String version() {
        return "1.0.0";
    }

    @Override
    public List<Capability> capabilities() {
        Capability echo = Capability.builder("echo", ApiScope.READ, (context, args) -> {
                    JSONObject out = new JSONObject();
                    out.put("echo", args.getString("text"));
                    return out;
                })
                .description("Returns the text you send (connectivity test for the SDK path)")
                .arg("text", Capability.ArgType.STRING, true, "Any short text")
                .build();

        Capability deviceInfo = Capability.builder("device_info", ApiScope.READ, (context, args) -> {
                    JSONObject out = new JSONObject();
                    out.put("manufacturer", Build.MANUFACTURER);
                    out.put("model", Build.MODEL);
                    out.put("androidVersion", Build.VERSION.RELEASE);
                    out.put("sdkInt", Build.VERSION.SDK_INT);
                    return out;
                })
                .description("Phone model and Android version")
                .build();

        return Arrays.asList(echo, deviceInfo);
    }
}
