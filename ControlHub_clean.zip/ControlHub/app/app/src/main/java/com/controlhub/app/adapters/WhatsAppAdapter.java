package com.controlhub.app.adapters;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Step 4 — WhatsApp adapter: action "send_message" (args: contact, message).
 *
 *  Mode A (background): notification inline reply   ->  reply:<pkg>|<contact>|<message>
 *  Mode B (foreground): search -> chat kholo -> type -> send (har step par post-condition)
 *
 * IMPORTANT (honest): Mode B ke selector ids (menuitem_search, entry, send, ...) WhatsApp ke
 * UI ki known naming par based "starter" definitions hain. WhatsApp inhe version ke saath badalta
 * hai, aur maine inhe real phone par verify NAHI kiya. Content-desc/text alternates fallback ke
 * liye hain. Pehle device test mein ye adjust honge — status() isiliye "starter" batata hai.
 */
public class WhatsAppAdapter implements AppAdapter {

    private final String name;
    private final String pkg;

    public WhatsAppAdapter(String name, String pkg) {
        this.name = name;
        this.pkg = pkg;
    }

    @Override public String name() { return name; }
    @Override public String packageName() { return pkg; }
    @Override public String description() { return "Send a WhatsApp message (inline reply if possible, else UI automation)"; }
    @Override public int version() { return 1; }
    @Override public String status() { return "starter (selectors not yet verified on a real device)"; }
    @Override public List<String> actions() { return Arrays.asList("send_message"); }

    @Override
    public boolean supportsBackground(String action) {
        return "send_message".equals(action);
    }

    @Override
    public List<String> expand(String action, String[] args, boolean background) {
        if (!"send_message".equals(action)) {
            throw new IllegalArgumentException("Unknown " + name + " action: " + action + " (supported: send_message)");
        }
        if (args.length < 2 || args[0].trim().isEmpty() || args[1].isEmpty()) {
            throw new IllegalArgumentException("send_message needs: do:" + name + ".send_message|<contact>|<message>");
        }
        String contact = args[0].trim();
        String message = args[1];

        List<String> out = new ArrayList<>();
        if (background) {
            out.add("reply:" + pkg + "|" + contact + "|" + message);
            return out;
        }

        // Mode B — foreground UI flow
        out.add("open:" + pkg + " => pkg:" + pkg);
        out.add("tap:desc=Search || id=menuitem_search => appears:cls=EditText");
        out.add("type:" + contact);
        out.add("tap:id=conversations_row_contact_name & has=" + contact
                + " || cls=TextView & has=" + contact
                + " => appears:id=entry || id=conversation_contact_name & has=" + contact);
        out.add("tap:id=entry || cls=EditText => appears:id=entry || cls=EditText");
        out.add("type:" + message);
        out.add("tap:id=send || desc=Send => gone:id=send && text:" + message);
        return out;
    }
}
