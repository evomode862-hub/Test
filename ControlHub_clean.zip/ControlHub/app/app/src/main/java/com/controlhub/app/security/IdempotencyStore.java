package com.controlhub.app.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Step 6 — Idempotency keys = replay protection (PURE JAVA, test-able).
 *
 * Same key + same request (method+uri+body) dobara aaye (retry ya replay) to dobara EXECUTE nahi hota —
 * pehle wala jawab wapas jata hai. Same key par DOOSRI request ho to reject. 10 minute TTL, max 500 keys.
 * Sirf safal (2xx) jawab cache hote hain; fail hone par key hata di jaati hai taaki client dobara try kar sake.
 */
public class IdempotencyStore {

    public enum Kind { NEW, REPLAY, CONFLICT, IN_PROGRESS }

    public static class Decision {
        public final Kind kind;
        public final int status;
        public final String body;

        Decision(Kind kind, int status, String body) {
            this.kind = kind;
            this.status = status;
            this.body = body;
        }
    }

    private static final class Entry {
        final String fingerprint;
        final long createdAt;
        boolean done;
        int status;
        String body;

        Entry(String fingerprint, long createdAt) {
            this.fingerprint = fingerprint;
            this.createdAt = createdAt;
        }
    }

    public static final long TTL_MS = 10 * 60_000;
    private static final int MAX_ENTRIES = 500;

    private final RateLimiter.Clock clock;
    private final LinkedHashMap<String, Entry> entries = new LinkedHashMap<>();

    public IdempotencyStore() {
        this(new RateLimiter.Clock() {
            @Override
            public long now() {
                return System.currentTimeMillis();
            }
        });
    }

    public IdempotencyStore(RateLimiter.Clock clock) {
        this.clock = clock;
    }

    public static String fingerprint(String method, String uri, String body) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest((method + " " + uri + " " + body).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(Character.forDigit((b >> 4) & 0xF, 16)).append(Character.forDigit(b & 0xF, 16));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static boolean isValidKey(String key) {
        return key != null && key.matches("[A-Za-z0-9_.:\\-]{8,100}");
    }

    private void evictExpired(long now) {
        Iterator<Map.Entry<String, Entry>> it = entries.entrySet().iterator();
        while (it.hasNext()) {
            if (now - it.next().getValue().createdAt >= TTL_MS) it.remove();
        }
    }

    public synchronized Decision begin(String key, String fingerprint) {
        long now = clock.now();
        evictExpired(now);
        Entry e = entries.get(key);
        if (e != null) {
            if (!e.fingerprint.equals(fingerprint)) return new Decision(Kind.CONFLICT, 0, null);
            if (!e.done) return new Decision(Kind.IN_PROGRESS, 0, null);
            return new Decision(Kind.REPLAY, e.status, e.body);
        }
        while (entries.size() >= MAX_ENTRIES) {
            String oldest = entries.keySet().iterator().next();
            entries.remove(oldest);
        }
        entries.put(key, new Entry(fingerprint, now));
        return new Decision(Kind.NEW, 0, null);
    }

    public synchronized void complete(String key, int status, String body) {
        Entry e = entries.get(key);
        if (e == null) return;
        if (status >= 200 && status < 300) {
            e.done = true;
            e.status = status;
            e.body = body;
        } else {
            entries.remove(key); // fail — dobara try karne do
        }
    }

    public synchronized void abandon(String key) {
        entries.remove(key);
    }
}
