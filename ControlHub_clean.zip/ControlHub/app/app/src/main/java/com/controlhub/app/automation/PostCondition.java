package com.controlhub.app.automation;

import com.controlhub.app.accessibility.UiElement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Step 3 — Post-condition: action ke BAAD kya sach hona chahiye. Command ke peeche " => " se likhte hain.
 *
 *   appears:<selector>   ye element screen par dikhna chahiye
 *   gone:<selector>      ye element ab nahi dikhna chahiye
 *   pkg:<package>        foreground app yahi honi chahiye
 *   text:<substring>     screen par kahin ye text (ya content-desc) ho
 *   none                 jaan-boojh kar verify band (audit mein "unverified" likha jaata hai)
 *
 * Kai conditions " && " se: tap:desc=Send => gone:text=Sending && appears:desc=Delivered
 */
public class PostCondition {

    public enum Kind { APPEARS, GONE, PKG, TEXT, NONE }

    public final Kind kind;
    public final List<Selector> selectors; // APPEARS / GONE
    public final String value;             // PKG / TEXT

    private PostCondition(Kind kind, List<Selector> selectors, String value) {
        this.kind = kind;
        this.selectors = selectors;
        this.value = value;
    }

    public static boolean looksLikeCondition(String s) {
        String t = s.trim();
        return t.startsWith("appears:") || t.startsWith("gone:") || t.startsWith("pkg:")
                || t.startsWith("text:") || t.equals("none");
    }

    public static List<PostCondition> parseList(String raw) {
        List<PostCondition> out = new ArrayList<>();
        for (String part : raw.trim().split("\\s&&\\s")) {
            out.add(parse(part.trim()));
        }
        return out;
    }

    public static PostCondition parse(String c) {
        if (c.equals("none")) return new PostCondition(Kind.NONE, null, null);
        int colon = c.indexOf(':');
        if (colon < 0) throw new IllegalArgumentException("Bad post-condition: " + c);
        String name = c.substring(0, colon).trim();
        String arg = c.substring(colon + 1).trim();
        if (arg.isEmpty()) throw new IllegalArgumentException("Empty post-condition: " + c);
        switch (name) {
            case "appears": return new PostCondition(Kind.APPEARS, Selector.parseAlternates(arg), null);
            case "gone": return new PostCondition(Kind.GONE, Selector.parseAlternates(arg), null);
            case "pkg": return new PostCondition(Kind.PKG, null, arg);
            case "text": return new PostCondition(Kind.TEXT, null, arg);
            default: throw new IllegalArgumentException("Unknown post-condition: " + name);
        }
    }

    public static PostCondition pkg(String packageName) {
        return new PostCondition(Kind.PKG, null, packageName);
    }

    /** null = condition poori; warna na-poori hone ki wajah (message content ke bina) */
    public String check(AutomationObserver.ObservedState state) {
        switch (kind) {
            case NONE:
                return null;
            case APPEARS:
                return Selector.resolveAll(state.elements, selectors).isEmpty()
                        ? "expected element not on screen" : null;
            case GONE:
                return Selector.resolveAll(state.elements, selectors).isEmpty()
                        ? null : "element still on screen";
            case PKG:
                return value.equals(state.foregroundPackage) ? null
                        : "foreground app is '" + state.foregroundPackage + "', expected '" + value + "'";
            case TEXT:
                String needle = value.toLowerCase();
                for (UiElement el : state.elements) {
                    if ((el.text != null && el.text.toLowerCase().contains(needle))
                            || (el.contentDesc != null && el.contentDesc.toLowerCase().contains(needle))) {
                        return null;
                    }
                }
                return "expected text not on screen";
            default:
                return "unknown condition";
        }
    }

    public static List<PostCondition> none() {
        return Collections.emptyList();
    }
}
