package com.controlhub.app.apkhost;

import android.content.Context;

/**
 * Feature #47 — RuntimeAdapter abstraction
 *
 * Ye interface isliye hai taaki "APK ko chalane ka tareeka" future mein badla
 * ja sake bina baaki system ko chhue — abhi ek hi implementation hai
 * (ExternalLaunchRuntimeAdapter, Feature #48/49), jo honestly sirf normal
 * Android launch karta hai. Agar kabhi koi real container/virtualization
 * runtime add karna ho, wo bas is interface ko implement karega.
 */
public interface RuntimeAdapter {

    class LaunchResult {
        public final boolean launched;
        public final boolean trulyEmbedded; // Feature #48/49 — kabhi bhi galat "true" mat do
        public final String message;

        public LaunchResult(boolean launched, boolean trulyEmbedded, String message) {
            this.launched = launched;
            this.trulyEmbedded = trulyEmbedded;
            this.message = message;
        }
    }

    /** Feature #48 — ye APK is runtime ke through chalaya ja sakta hai ya nahi */
    boolean isSupported(Context context, HostedApkEntity apk);

    /** Feature #49 — chalane ki koshish; supported na ho to clear fallback/error dena */
    LaunchResult launch(Context context, HostedApkEntity apk);
}
