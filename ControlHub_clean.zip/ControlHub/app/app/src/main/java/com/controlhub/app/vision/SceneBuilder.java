package com.controlhub.app.vision;

import android.graphics.Bitmap;
import android.util.Base64;

import com.controlhub.app.accessibility.ControlHubAccessibilityService;
import com.controlhub.app.accessibility.UiElement;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * Feature #36 — Screenshot ko clean/structured format mein convert karna
 * Feature #38 — Poora data AI (Claude) ko bhejne layak ek JSON package mein taiyar karna
 *
 * Output ek "scene" hai: current screenshot (base64 PNG, agar available ho) +
 * har element ka semantic label (Feature #37 se) + uski position/properties.
 * Ye wahi format hai jo aage (Stage 13, MCP) ke through Claude ko bheja jayega
 * taaki wo "insaan jaisa dekh ke" faisla le sake.
 */
public class SceneBuilder {

    public JSONObject buildScene(List<UiElement> elements, boolean includeScreenshot) {
        JSONObject scene = new JSONObject();

        try {
            scene.put("timestamp", System.currentTimeMillis());
            scene.put("elements", buildElementsArray(elements));

            if (includeScreenshot) {
                String screenshotBase64 = captureScreenshotBase64();
                if (screenshotBase64 != null) {
                    scene.put("screenshot_base64", screenshotBase64);
                    scene.put("screenshot_format", "png");
                } else {
                    scene.put("screenshot_base64", JSONObject.NULL);
                    scene.put("screenshot_unavailable_reason",
                            "Screenshot not available (needs Android 11+ and Accessibility Service running)");
                }
            }
        } catch (JSONException e) {
            // JSONObject.put() sirf tab exception deta hai jab key null ho — yahan
            // saari keys hardcoded/non-null hain, isliye ye practically kabhi nahi chalega
        }

        return scene;
    }

    // Feature #37 — har element ke saath uska semantic role bhi jodta hai
    private JSONArray buildElementsArray(List<UiElement> elements) throws JSONException {
        JSONArray array = new JSONArray();
        for (UiElement el : elements) {
            JSONObject obj = new JSONObject();
            obj.put("elementId", el.elementId);
            obj.put("role", RoleClassifier.classify(el));
            obj.put("text", el.text);
            obj.put("resourceId", el.resourceId);
            obj.put("contentDesc", el.contentDesc);   // Step 8: icon-only buttons ke liye zaroori (agent loop)
            obj.put("package", el.packageName);
            obj.put("enabled", el.enabled);
            obj.put("focused", el.focused);
            obj.put("clickable", el.clickable);
            obj.put("scrollable", el.scrollable);
            obj.put("editable", el.editable);

            JSONObject bounds = new JSONObject();
            bounds.put("left", el.bounds.left);
            bounds.put("top", el.bounds.top);
            bounds.put("right", el.bounds.right);
            bounds.put("bottom", el.bounds.bottom);
            obj.put("bounds", bounds);

            array.put(obj);
        }
        return array;
    }

    // Feature #36 — Bitmap ko compress karke ek transferable string mein badalna
    private String captureScreenshotBase64() {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();
        if (service == null) return null;

        Bitmap bitmap = service.takeScreenshotSync(5000);
        if (bitmap == null) return null;

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP);
    }
}
