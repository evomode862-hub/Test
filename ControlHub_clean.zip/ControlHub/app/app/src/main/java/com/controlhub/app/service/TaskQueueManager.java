package com.controlhub.app.service;

import android.util.Log;

import com.controlhub.app.security.EmergencyStopManager;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Feature #29 — Task Queue
 * Feature #30 — Basic Recovery (submitAndWait mein ek retry)
 * Feature #57 — SDK modules ke liye submitOnce (retry NAHI, timeout hai)
 *
 * Insaan ek waqt mein ek hi action karta hai (ek tap khatam, tabhi agla).
 * Agar do commands ek saath aa jayein, to unhe seedha parallel chalne dena galat hai —
 * Accessibility Service confuse ho sakti hai. Ye class ek single-thread queue banati hai:
 * har action apni baari ka wait karta hai, ek-ek karke chalta hai.
 */
public class TaskQueueManager {

    private static final String TAG = "TaskQueueManager";
    private static final TaskQueueManager INSTANCE = new TaskQueueManager();

    private volatile ExecutorService queue = Executors.newSingleThreadExecutor();

    private TaskQueueManager() {
    }

    public static TaskQueueManager getInstance() {
        return INSTANCE;
    }

    /**
     * Action ko queue mein daalta hai, apni baari ka wait karta hai, result deta hai.
     * Pehli koshish fail ho to ek baar dobara try karta hai (Feature #30).
     * NOTE: built-in actions (tap/scroll/launch...) ke liye hai jo dobara chalane par safe hain.
     */
    public <T> T submitAndWait(Callable<T> action) throws Exception {
        Future<T> future = queue.submit(() -> {
            // Feature #43 — Emergency Stop active ho to koi naya action chalne hi mat do
            if (EmergencyStopManager.isStopped()) {
                throw new IllegalStateException("Emergency stop is active — action rejected");
            }
            try {
                return action.call();
            } catch (Exception firstError) {
                Log.w(TAG, "Task failed first try, retrying once: " + firstError.getMessage());
                try {
                    Thread.sleep(300); // thodi si wait, taaki transient issue sudhar jaye
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
                if (EmergencyStopManager.isStopped()) {
                    throw new IllegalStateException("Emergency stop is active — retry aborted");
                }
                return action.call(); // dusri koshish — is baar fail hui to upar throw hoga
            }
        });

        return future.get();
    }

    /**
     * Feature #57 — third-party / SDK handlers ke liye.
     *
     * submitAndWait se do farq:
     *  1. RETRY NAHI — pata nahi handler ka side-effect dobara chalane par safe hai ya nahi
     *     (jaise "message bhejo" do baar chal jaye to do message jaayenge).
     *  2. TIMEOUT — koi handler atak jaye to poori queue (aur uske peeche ke tap/scroll)
     *     hamesha ke liye block na ho. Timeout par queue naye thread pe recover hoti hai.
     *
     * Handler ki original exception (jaise IllegalArgumentException) wrap kiye bina throw hoti hai.
     */
    public <T> T submitOnce(Callable<T> action, long timeoutMs) throws Exception {
        Future<T> future = queue.submit(() -> {
            if (EmergencyStopManager.isStopped()) {
                throw new IllegalStateException("Emergency stop is active — action rejected");
            }
            return action.call();
        });

        try {
            return future.get(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (TimeoutException te) {
            future.cancel(true);
            recoverQueue();
            throw new TimeoutException("Action timed out after " + timeoutMs + " ms");
        } catch (ExecutionException ee) {
            Throwable cause = ee.getCause();
            if (cause instanceof Exception) {
                throw (Exception) cause;
            }
            throw ee;
        }
    }

    /**
     * Atke hue thread ko interrupt karke chhod do, naya thread bana do. Queue mein jo
     * tasks peeche wait kar rahe the unhe cancel karte hain (warna unke callers
     * future.get() par hamesha ke liye latak jaate).
     */
    private synchronized void recoverQueue() {
        ExecutorService old = queue;
        queue = Executors.newSingleThreadExecutor();
        List<Runnable> dropped = old.shutdownNow();
        for (Runnable r : dropped) {
            if (r instanceof Future) {
                ((Future<?>) r).cancel(true);
            }
        }
        Log.w(TAG, "Task queue recovered after a timeout (" + dropped.size() + " queued tasks cancelled)");
    }
}
