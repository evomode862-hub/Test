package com.controlhub.app.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Feature #3 — Local database
 * Ek row = ek setting (key-value). Feature #4 ka Settings screen isko use karega.
 */
@Entity(tableName = "settings")
public class SettingEntity {

    @PrimaryKey
    @NonNull
    public String key;

    public String value;

    public SettingEntity(@NonNull String key, String value) {
        this.key = key;
        this.value = value;
    }
}
