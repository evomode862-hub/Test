package com.controlhub.app.sdk;

import java.util.List;

/**
 * Feature #57 — Developer SDK: ek module = related capabilities ka group.
 *
 * Naya module likhne ke liye:
 *   1. is interface ko implement karo (name, version, capabilities)
 *   2. ModuleBootstrap.registerAll() mein ek line jodo
 * Bas. Phir ye endpoint mil jaata hai:  POST /x/<module>/<capability>
 * aur /capabilities manifest mein khud dikhne lagta hai.
 *
 * SAFETY DESIGN: modules COMPILE-TIME par app ke andar hote hain. Runtime par koi
 * unknown code (DexClassLoader / downloaded plugin) load NAHI hota — is app ke paas
 * Accessibility Service jaisi bhaari power hai, isliye "kisi ne bheja plugin chala do"
 * wala tareeka jaanbujh ke nahi rakha.
 */
public interface CapabilityModule {

    /** Chhota naam: a-z, 0-9, _ ; pehla akshar letter ; 2-32 chars. URL ka hissa banta hai. */
    String name();

    String version();

    List<Capability> capabilities();
}
