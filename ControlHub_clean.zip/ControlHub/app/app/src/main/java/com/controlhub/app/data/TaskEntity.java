package com.controlhub.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.UUID;

/**
 * Feature #3 — Local database
 * Ek row = ek automation task (Step 2: spec ke hisaab se poori state persist hoti hai,
 * taaki process kill / restart ke baad task wahin se resume ho sake).
 *
 * status: pending | running | paused | done | failed | cancelled
 */
@Entity(tableName = "tasks")
public class TaskEntity {

    public static final String REDACTED = "[redacted]";


    @PrimaryKey(autoGenerate = true)
    public long id;

    public String instructions;
    public String status;
    public long createdAt;
    public long updatedAt;

    // ---- Step 2 fields ----
    public String taskUuid = UUID.randomUUID().toString(); // bahar ki duniya ke liye unique task_id
    public String deviceId = "";        // is phone ki pehchaan (Settings/relay se aata hai)
    public int priority = 0;            // bada number = pehle chalega (-10..10)
    public long deadlineAt = 0;         // epoch ms; 0 = koi deadline nahi
    public int currentStep = 0;         // checkpoint: kitne commands safal ho chuke
    public int retryCount = 0;          // total failed attempts (act/verify)
    public int recoveryCount = 0;       // process-kill ke baad kitni baar resume hua
    public String lastError;            // aakhri failure ki wajah
    public String mode = "foreground";  // Step 4: "background" (Mode A) | "foreground" (Mode B)

    // ---- Step 8 fields ----
    public boolean redactWhenDone = false; // true = task khatam hote hi instructions (message text) mita do
    public boolean restoreApp = true;      // foreground task khatam hone par pichli app par wapas
    public String startPackage = "";       // task shuru hone se pehle foreground app

    public TaskEntity(String instructions, String status, long createdAt, long updatedAt) {
        this.instructions = instructions;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
}
