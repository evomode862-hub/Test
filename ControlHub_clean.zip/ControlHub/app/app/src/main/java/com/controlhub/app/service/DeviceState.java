package com.controlhub.app.service;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.PowerManager;

/** Step 4/7 — Foreground (Mode B) UI automation ke liye phone ki halat: screen, lock, battery. */
public class DeviceState {

    private static final int LOW_BATTERY_PERCENT = 10;

    public static class Battery {
        public int level = -1;          // 0..100, -1 = pata nahi
        public boolean charging = false;
        public boolean powerSave = false;
    }

    /** null = UI chala sakte hain; warna wajah */
    public static String uiBlockedReason(Context context) {
        Context app = context.getApplicationContext();
        PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) return "screen is off";
        KeyguardManager km = (KeyguardManager) app.getSystemService(Context.KEYGUARD_SERVICE);
        if (km != null && km.isKeyguardLocked()) return "device is locked";
        return null;
    }

    public static Battery battery(Context context) {
        Context app = context.getApplicationContext();
        Battery b = new Battery();
        Intent i = app.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); // sticky
        if (i != null) {
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (level >= 0 && scale > 0) b.level = Math.round(100f * level / scale);
            int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            b.charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        }
        PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
        b.powerSave = pm != null && pm.isPowerSaveMode();
        return b;
    }

    /** Foreground (UI) automation battery bachane ke liye ruk jaati hai: <=10% aur charging nahi. null = theek */
    public static String lowBatteryReason(Context context) {
        Battery b = battery(context);
        if (b.level >= 0 && b.level <= LOW_BATTERY_PERCENT && !b.charging) {
            return "battery at " + b.level + "% and not charging";
        }
        return null;
    }
}
