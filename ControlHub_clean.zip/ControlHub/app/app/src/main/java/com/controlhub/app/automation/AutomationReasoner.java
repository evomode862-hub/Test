package com.controlhub.app.automation;

import java.util.ArrayList;
import java.util.List;

/**
 * Feature #32 — Reason
 *
 * Honest note: abhi bhi rule-based (asli AI/natural-language reasoning baad ke step mein).
 * Step 3: selectors + post-conditions + recovery ladder.
 *
 * Commands nayi line ya ";;" se alag. Syntax ke liye AutomationCommand / Selector / PostCondition dekho.
 * Example:
 *   open:com.whatsapp => pkg:com.whatsapp
 *   tap:desc=Search || id=menuitem_search
 *   tap:has=Ibrahim & within=Chats
 *   type:Hello
 *   tap:id=send || desc=Send || xy=980,2150 => gone:desc=Send
 */
public class AutomationReasoner {

    private static final String SEPARATOR_REGEX = "\\s*(?:;;|\\r?\\n)\\s*";
    private static final int MAX_RECOVERY_SCROLLS = 2;

    /** Raw instructions ko commands ki strings mein todta hai */
    public static List<String> parseCommands(String instructions) {
        List<String> out = new ArrayList<>();
        if (instructions == null) return out;
        for (String part : instructions.trim().split(SEPARATOR_REGEX)) {
            String c = part.trim();
            if (!c.isEmpty()) out.add(c);
        }
        return out;
    }

    /** Poori instructions ko parsed commands mein badalta hai (@throws IllegalArgumentException) */
    public static List<AutomationCommand> parse(String instructions) {
        List<AutomationCommand> out = new ArrayList<>();
        for (String c : parseCommands(instructions)) {
            out.add(AutomationCommand.parse(c));
        }
        return out;
    }

    public AutomationStep decide(AutomationObserver.ObservedState state, List<AutomationCommand> commands,
                                 int stepIndex, RecoveryContext rc) {
        if (commands.isEmpty()) {
            return AutomationStep.fail("Task has no instructions");
        }
        if (stepIndex >= commands.size()) {
            return AutomationStep.done("all " + commands.size() + " command(s) completed");
        }

        AutomationCommand cmd = commands.get(stepIndex);
        AutomationStep step;

        switch (cmd.action) {
            case OPEN:
                step = AutomationStep.launchApp(cmd.arg, "command asked to open app");
                break;

            case TAP:
            case LONGTAP: {
                List<Selector.Match> matches = Selector.resolveAll(state.elements, cmd.selectors);
                if (matches.isEmpty()) {
                    // Recovery: shayad element scroll ke neeche hai
                    if (rc.scrollsTried < MAX_RECOVERY_SCROLLS) {
                        AutomationStep scroll = AutomationStep.scroll("down", "element not found — scrolling to look for it");
                        scroll.recovery = true;
                        return scroll;
                    }
                    return AutomationStep.fail("No element matched any selector (tried " + cmd.selectors.size()
                            + " selector(s), scrolled " + rc.scrollsTried + "x)");
                }
                // Pehli koshish: best. Fail hone par: agla (alternate) candidate.
                int pick = Math.min(rc.failuresOnStep, matches.size() - 1);
                Selector.Match m = matches.get(pick);
                step = AutomationStep.tapMatch(m, "selector '" + m.selector.kind() + "' matched (candidate "
                        + (pick + 1) + "/" + matches.size() + ")");
                step.longPress = cmd.action == AutomationCommand.Action.LONGTAP;
                break;
            }

            case TYPE:
                step = AutomationStep.typeText(cmd.arg, "command asked to type text");
                break;

            case SCROLL:
                step = AutomationStep.scroll(cmd.arg, "command asked to scroll " + cmd.arg);
                break;

            case BACK:
                step = AutomationStep.pressBack("command asked to go back");
                break;

            case HOME:
                step = AutomationStep.pressHome("command asked to go home");
                break;

            case KEY:
                step = AutomationStep.pressKey(cmd.arg, "command asked to press key " + cmd.arg);
                break;

            case REPLY:
                step = new AutomationStep(AutomationStep.Type.REPLY);
                step.packageName = cmd.pkg;
                step.replyTarget = cmd.target;
                step.text = cmd.arg;
                step.reason = "command asked for inline reply (background)";
                break;

            case WAIT:
                step = new AutomationStep(AutomationStep.Type.WAIT);
                step.waitSeconds = cmd.seconds;
                step.reason = "command asked to wait " + cmd.seconds + "s";
                break;

            default:
                return AutomationStep.fail("Unsupported command");
        }

        step.conditions = cmd.conditions;
        return step;
    }
}
