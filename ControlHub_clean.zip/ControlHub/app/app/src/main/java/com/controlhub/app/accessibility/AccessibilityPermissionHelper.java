package com.controlhub.app.accessibility;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.text.TextUtils;

/**
 * Feature #11 — Accessibility permission request flow
 *
 * Android AccessibilityService ek "special permission" hai — user ko khud
 * Settings > Accessibility mein jaake app ko manually on karna padta hai,
 * normal runtime permission popup se nahi milti. Ye class:
 *  1. check karta hai ki service already on hai ya nahi
 *  2. na ho to seedha Settings screen khol deta hai, user ko on karne ke liye
 */
public class AccessibilityPermissionHelper {

    public static boolean isServiceEnabled(Context context) {
        String enabledServices = Settings.Secure.getString(
                context.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);

        if (TextUtils.isEmpty(enabledServices)) {
            return false;
        }

        ComponentName expected = new ComponentName(context, ControlHubAccessibilityService.class);
        String expectedFlat = expected.flattenToString();

        for (String service : enabledServices.split(":")) {
            if (service.equalsIgnoreCase(expectedFlat)) {
                return true;
            }
        }
        return false;
    }

    public static void openAccessibilitySettings(Context context) {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
