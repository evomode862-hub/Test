package com.controlhub.app.automation;

import android.content.Context;
import android.util.Log;

import com.controlhub.app.data.AppDatabase;
import com.controlhub.app.data.TaskDao;
import com.controlhub.app.data.TaskEntity;
import com.controlhub.app.security.AuditLogger;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Step 6 — Watchdog (har 60 sec, foreground service ke andar):
 *  - 'running' task jo kisi runner ke paas nahi aur 3 min se update nahi hua  -> stale: wapas queue (max 2 baar) ya failed
 *  - 'pending' task jiski deadline guzar gayi -> failed ("deadline passed while queued")
 *  - 'pending' task jo kisi queue mein nahi (enqueue kho gaya) -> dobara enqueue
 *  - Audit log ki size bound (sirf latest 5000 rows) — har ghante
 * Emergency Stop ON ho to kuch re-queue nahi karta.
 */
public class TaskWatchdog {

    private static final String TAG = "TaskWatchdog";
    private static final long STALE_RUNNING_MS = 3 * 60_000;
    private static final long ORPHAN_PENDING_MS = 90_000;
    private static final int MAX_RECOVERIES = 2;
    private static final int KEEP_LOG_ROWS = 5000;
    private static final AtomicBoolean STARTED = new AtomicBoolean(false);
    private static volatile long lastLogPrune = 0;
    private static volatile long lastTaskPrune = 0;

    public static void start(Context context) {
        if (!STARTED.compareAndSet(false, true)) return;
        final Context app = context.getApplicationContext();
        ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor();
        ses.scheduleWithFixedDelay(() -> {
            try {
                sweep(app, System.currentTimeMillis());
            } catch (Throwable t) {
                Log.e(TAG, "Watchdog sweep failed", t);
            }
        }, 60, 60, TimeUnit.SECONDS);
    }

    static void sweep(Context app, long now) {
        AppDatabase db = AppDatabase.getInstance(app);
        TaskDao dao = db.taskDao();
        boolean stopped = com.controlhub.app.security.EmergencyStopManager.isStopped();

        for (TaskEntity t : dao.getByStatus("running")) {
            if (t.id == TaskRunner.currentTaskId()) continue; // chal raha hai
            if (now - t.updatedAt < STALE_RUNNING_MS) continue;
            if (stopped || (t.deadlineAt > 0 && now > t.deadlineAt) || t.recoveryCount >= MAX_RECOVERIES) {
                if (dao.markFailed(t.id, now, "Watchdog: task was stuck (no progress for 3 min)") > 0) {
                    AuditLogger.error(app, "Watchdog failed stale task " + t.id);
                }
            } else if (dao.markInterrupted(t.id, now) > 0) {
                AuditLogger.warning(app, "Watchdog re-queued stale task " + t.id);
                TaskRunner.enqueue(app, t.id, t.priority);
            }
        }

        for (TaskEntity t : dao.getByStatus("pending")) {
            if (t.deadlineAt > 0 && now > t.deadlineAt) {
                if (dao.markFailed(t.id, now, "Deadline passed while waiting in the queue") > 0) {
                    AuditLogger.error(app, "Watchdog failed expired pending task " + t.id);
                }
            } else if (!stopped && !TaskRunner.isQueued(t.id) && t.id != TaskRunner.currentTaskId()
                    && now - t.updatedAt > ORPHAN_PENDING_MS) {
                TaskRunner.enqueue(app, t.id, t.priority);
            }
        }

        // Step 8: redactWhenDone wale khatam tasks ka text mita do (catch-all) + 7 din purane khatam tasks delete
        dao.redactFinishedFlagged();
        if (now - lastTaskPrune > 60L * 60_000) {
            lastTaskPrune = now;
            if (TaskRetention.isAutoDeleteEnabled(app)) {
                int n = dao.purgeFinished(now - TaskRetention.RETENTION_MS, null);
                if (n > 0) AuditLogger.info(app, "Auto-deleted " + n + " finished task(s) older than 7 days");
            }
        }

        if (now - lastLogPrune > 60L * 60_000) {
            lastLogPrune = now;
            db.logDao().keepLatest(KEEP_LOG_ROWS);
        }
    }
}
